package app.autopiano

import app.autopiano.core.KeySink

class TouchSink : KeySink {
    private fun inj(): TouchInjector {
        val svc = TouchAccessibilityService.instance
            ?: throw IllegalStateException("Turn on the Auto Piano accessibility service first")
        val cal = Engine.calibration()
            ?: throw IllegalStateException("Calibrate touch positions first")
        svc.injector.cal = cal
        return svc.injector
    }

    override fun down(pitch: Int) = inj().down(pitch)
    override fun up(pitch: Int) = inj().up(pitch)
    override fun pedal(down: Boolean) = inj().pedal(down)
}
