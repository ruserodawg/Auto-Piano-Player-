package app.autopiano;

interface IKeyInjector {
    void destroy() = 16777114;          // required by Shizuku
    boolean ready() = 1;
    String error() = 2;
    void key(int keyCode, boolean down, boolean shift) = 3;
    void touch(float x, float y, boolean down) = 4;
    void releaseAll() = 5;
}
