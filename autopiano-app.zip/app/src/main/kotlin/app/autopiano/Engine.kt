package app.autopiano

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.PointF
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.widget.Toast
import app.autopiano.core.MidiParser
import app.autopiano.core.PlayState
import app.autopiano.core.Player
import app.autopiano.core.Settings
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList

/** One MIDI file in the library. [key] is the file path (app folder) or the document URI (chosen folder). */
class MidiItem(val name: String, val key: String, val file: File?)

/** Process-wide singleton: one Player, prefs, MIDI library. Shared by the activity and the overlay. */
object Engine {
    private lateinit var app: Context
    private lateinit var prefs: SharedPreferences
    val main = Handler(Looper.getMainLooper())
    val player = Player(TouchSink())
    val listeners = CopyOnWriteArrayList<() -> Unit>()
    @Volatile var loading = false
    @Volatile var hasSong = false
    @Volatile var library: List<MidiItem> = emptyList()
    @Volatile private var calCache: Calibration? = null
    @Volatile private var calCacheKey = ""

    fun init(c: Context) {
        if (::app.isInitialized) return
        app = c.applicationContext
        prefs = app.getSharedPreferences("autopiano", Context.MODE_PRIVATE)
        player.onState = { notifyUi() }
        player.onError = { e -> toast(e.message ?: e.toString()); notifyUi() }
        player.setTempo(prefs.getInt("tempo", 100) / 100.0)
        applySettings()
        refreshLibrary(loadSaved = true)
    }

    fun notifyUi() { main.post { listeners.forEach { it() } } }
    fun toast(msg: String) { main.post { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() } }

    // ---- prefs ----
    fun getBool(k: String, def: Boolean) = prefs.getBoolean(k, def)
    fun setBool(k: String, v: Boolean) { prefs.edit().putBoolean(k, v).apply() }
    fun getInt(k: String, def: Int) = prefs.getInt(k, def)
    fun setInt(k: String, v: Int) { prefs.edit().putInt(k, v).apply() }
    fun is88() = prefs.getBoolean("is88", false)
    fun setIs88(v: Boolean) { setBool("is88", v); calCache = null; applySettings() }

    /** Most touches Android lets us hold at once, minus one for the pedal if there is one. */
    fun voiceLimit(): Int {
        val m = TouchAccessibilityService.instance?.injector?.maxStrokes ?: 10
        return (m - (if (layout()?.pedal != null) 1 else 0)).coerceIn(3, 20)
    }

    fun settings(): Settings {
        val big = is88()
        return Settings(
            low = if (big) 21 else 36, high = if (big) 108 else 96,
            humanize = getBool("human", false), humanIntensity = getInt("hInt", 30) / 100.0,
            tempoJitter = getBool("jitter", false), jitterIntensity = getInt("jInt", 30) / 100.0,
            followMidiPedal = getBool("follow", true),
            arpMs = getInt("arp", 10).toDouble(), maxVoices = voiceLimit()
        )
    }

    fun applySettings() = player.configure(settings())

    fun setTempoPercent(p: Int) { setInt("tempo", p); player.setTempo(p / 100.0) }

    /** Shown on the main screen: what the last song needed from the touch limit, and any failed gestures. */
    fun diag(): String {
        val inj = TouchAccessibilityService.instance?.injector
        val base = "Touch limit: ${voiceLimit()} notes at once. Notes shortened to fit in this song: ${player.cutNotes()}."
        return if (inj == null) base else "$base Gestures cancelled: ${inj.cancelled}, failed: ${inj.failed}."
    }

    // ---- piano overlay layout, stored per 61/88 mode and per screen orientation ----
    private fun ck(): String {
        val land = app.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        return (if (is88()) "p88" else "p61") + (if (land) "L" else "P")
    }

    fun orientationName() =
        if (app.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) "landscape" else "portrait"

    fun layout(): Layout? {
        val k = ck()
        if (!prefs.contains("$k.l")) return null
        val px = prefs.getFloat("$k.px", -1f)
        return Layout(
            prefs.getFloat("$k.l", 0f), prefs.getFloat("$k.t", 0f), prefs.getFloat("$k.r", 0f), prefs.getFloat("$k.b", 0f),
            if (px >= 0) PointF(px, prefs.getFloat("$k.py", 0f)) else null,
            prefs.getFloat("$k.fw", 0.8f), prefs.getFloat("$k.fb", 0.3f),
            prefs.getFloat("$k.ox", 0f), prefs.getFloat("$k.oy", 0f)
        )
    }

    fun saveLayout(l: Layout) {
        val k = ck()
        prefs.edit().putFloat("$k.l", l.l).putFloat("$k.t", l.t).putFloat("$k.r", l.r).putFloat("$k.b", l.b)
            .putFloat("$k.px", l.pedal?.x ?: -1f).putFloat("$k.py", l.pedal?.y ?: -1f)
            .putFloat("$k.fw", l.fw).putFloat("$k.fb", l.fb).putFloat("$k.ox", l.ox).putFloat("$k.oy", l.oy).apply()
        calCache = null
        applySettings()          // pedal presence changes the touch limit
        notifyUi()
    }

    fun calibrationFor(l: Layout, screen: Boolean = true): Calibration {
        val big = is88()
        return l.toCalibration(if (big) 21 else 36, if (big) 108 else 96, screen)
    }

    fun calibration(): Calibration? {
        val k = ck()
        calCache?.let { if (calCacheKey == k) return it }
        val l = layout() ?: return null
        val c = calibrationFor(l)
        calCache = c; calCacheKey = k
        return c
    }

    // ---- MIDI library: a folder you choose (read in place, nothing copied), or the app's own folder ----
    fun treeUri(): Uri? = prefs.getString("tree", null)?.let { Uri.parse(it) }

    fun setTree(u: Uri?) {
        prefs.edit().apply { if (u == null) remove("tree") else putString("tree", u.toString()) }.apply()
        refreshLibrary()
    }

    fun folderLabel(): String =
        treeUri()?.let { Uri.decode(it.lastPathSegment ?: it.toString()) } ?: "App folder: ${dir().path}"

    fun dir(): File = File(app.getExternalFilesDir(null) ?: app.filesDir, "midi").apply { mkdirs() }

    fun refreshLibrary(loadSaved: Boolean = false) {
        Thread {
            library = try { scan() } catch (e: Exception) { toast("Can't read the MIDI folder: ${e.message}"); emptyList() }
            notifyUi()
            if (loadSaved) {
                val k = prefs.getString("file", null)
                library.firstOrNull { it.key == k }?.let { loadItem(it) }
            }
        }.start()
    }

    private fun isMidi(name: String) = name.lowercase().let { it.endsWith(".mid") || it.endsWith(".midi") }

    private fun scan(): List<MidiItem> {
        val tree = treeUri()
        if (tree == null) {
            return (dir().listFiles { f -> isMidi(f.name) } ?: emptyArray())
                .map { MidiItem(it.name, it.absolutePath, it) }.sortedBy { it.name.lowercase() }
        }
        val out = ArrayList<MidiItem>()
        fun walk(docId: String, prefix: String, depth: Int) {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val cols = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            )
            app.contentResolver.query(children, cols, null, null, null)?.use { c ->
                while (c.moveToNext() && out.size < 3000) {
                    val id = c.getString(0) ?: continue
                    val name = c.getString(1) ?: continue
                    val mime = c.getString(2)
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                        if (depth < 3) walk(id, "$prefix$name/", depth + 1)
                    } else if (isMidi(name)) {
                        out.add(MidiItem(prefix + name, DocumentsContract.buildDocumentUriUsingTree(tree, id).toString(), null))
                    }
                }
            }
        }
        walk(DocumentsContract.getTreeDocumentId(tree), "", 0)
        return out.sortedBy { it.name.lowercase() }
    }

    fun currentName(): String? = prefs.getString("fileName", null)

    private fun loadItem(item: MidiItem) {
        loading = true; notifyUi()
        try {
            val bytes = if (item.file != null) item.file.readBytes()
            else app.contentResolver.openInputStream(Uri.parse(item.key))!!.use { it.readBytes() }
            player.load(MidiParser.parse(bytes))
            hasSong = true
        } catch (e: Exception) {
            hasSong = false
            toast("Can't read ${item.name}: ${e.message}")
        }
        loading = false; notifyUi()
    }

    fun select(item: MidiItem) {
        prefs.edit().putString("file", item.key).putString("fileName", item.name).apply()
        Thread { loadItem(item) }.start()
    }

    fun cycle(delta: Int) {
        val l = library
        if (l.isEmpty()) return
        val k = prefs.getString("file", null)
        val i = l.indexOfFirst { it.key == k }
        select(l[((if (i < 0) 0 else i) + delta + l.size) % l.size])
    }

    /** Only files in the app's own folder can be deleted here; files in your chosen folder are left alone. */
    fun delete(item: MidiItem) {
        val f = item.file
        if (f == null) { toast("Delete it from your file manager; the app only reads your folder."); return }
        if (item.key == prefs.getString("file", null)) {
            player.stop(); hasSong = false; prefs.edit().remove("file").remove("fileName").apply()
        }
        f.delete()
        refreshLibrary()
    }

    fun play(c: Context) {
        if (!hasSong) { toast("Pick a MIDI file first"); return }
        PlayerService.ensure(c)
        if (player.playState() == PlayState.STOPPED) applySettings()   // pick up the current touch limit
        player.play()
    }
}
