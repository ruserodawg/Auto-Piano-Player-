package app.autopiano

import android.graphics.PointF

/**
 * Touch layout from 4 taps: lowest white key, highest white key, any black key, pedal.
 * White keys are assumed evenly spaced; a black key sits halfway between its neighbours.
 */
class Calibration(
    val low: Int, val high: Int,
    private val leftX: Float, private val rightX: Float,
    private val whiteY: Float, private val blackY: Float,
    private val pedalX: Float, private val pedalY: Float
) {
    private val blackSemis = setOf(1, 3, 6, 8, 10)
    private fun isBlack(p: Int) = (p % 12) in blackSemis
    fun isBlackKey(p: Int) = isBlack(p)
    private val whiteCount = (low..high).count { !isBlack(it) }
    private val step = if (whiteCount > 1) (rightX - leftX) / (whiteCount - 1) else 0f
    private fun whiteIndex(p: Int) = (low until p).count { !isBlack(it) }

    fun point(p: Int): PointF? {
        if (p < low || p > high) return null
        val idx = whiteIndex(p)
        return if (isBlack(p)) PointF(leftX + (idx - 0.5f) * step, blackY)
        else PointF(leftX + idx * step, whiteY)
    }

    fun pedal(): PointF? = if (pedalX >= 0) PointF(pedalX, pedalY) else null
}
