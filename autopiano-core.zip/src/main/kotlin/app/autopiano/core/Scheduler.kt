package app.autopiano.core

import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

class Settings(
    val low: Int = 36,                 // lowest playable MIDI note (61-key: 36, 88-key: 21)
    val high: Int = 96,                // highest playable MIDI note (61-key: 96, 88-key: 108)
    val humanize: Boolean = false,
    val humanIntensity: Double = 0.3,  // 0..1
    val tempoJitter: Boolean = false,
    val jitterIntensity: Double = 0.3, // 0..1
    val followMidiPedal: Boolean = true,
    val seed: Long = 1234
)

/** Order matters at equal timestamps: release before re-press. */
enum class Kind { UP, PEDAL_UP, PEDAL_DOWN, DOWN }

class Action(val timeMs: Double, val kind: Kind, val pitch: Int = 0)

class Schedule(val actions: List<Action>, val hasPedal: Boolean)

object Scheduler {
    const val MIN_HOLD_MS = 30.0       // shortest key press we will emit
    private const val REPEAT_GAP_MS = 15.0

    private class N(var s: Double, var e: Double, val p: Int) { var dead = false }

    fun fold(pitch: Int, low: Int, high: Int): Int {
        var x = pitch
        while (x < low) x += 12
        while (x > high) x -= 12
        return x
    }

    fun build(song: Song, st: Settings): Schedule {
        val rnd = java.util.Random(st.seed)
        val ns = song.notes.map { N(it.startMs, it.endMs, fold(it.pitch, st.low, st.high)) }
        val pedal = song.pedal.map { doubleArrayOf(it.timeMs, if (it.down) 1.0 else 0.0) }

        if (st.humanize && st.humanIntensity > 0) humanize(ns, st.humanIntensity, rnd)
        if (st.tempoJitter && st.jitterIntensity > 0) jitter(ns, pedal, st.jitterIntensity, rnd)
        fixSamePitch(ns)

        val acts = ArrayList<Action>(ns.size * 2 + pedal.size)
        for (n in ns) if (!n.dead) {
            acts.add(Action(n.s, Kind.DOWN, n.p)); acts.add(Action(n.e, Kind.UP, n.p))
        }
        for (p in pedal) acts.add(Action(p[0], if (p[1] > 0.5) Kind.PEDAL_DOWN else Kind.PEDAL_UP))
        acts.sortWith(compareBy({ it.timeMs }, { it.kind.ordinal }))
        return Schedule(acts, pedal.isNotEmpty())
    }

    /**
     * Chords move as a unit (small per-note spread), on/off shift together so durations
     * are unchanged, and shifts are capped to 40% of the gap to neighbouring onsets so
     * rhythm/order is preserved. Offsets are relative to the original time -> no drift.
     */
    private fun humanize(ns: List<N>, intensity: Double, rnd: java.util.Random) {
        val sorted = ns.sortedBy { it.s }
        val groups = ArrayList<MutableList<N>>()
        for (n in sorted) {
            if (groups.isNotEmpty() && n.s - groups.last()[0].s < 3.0) groups.last().add(n)
            else groups.add(mutableListOf(n))
        }
        for ((i, g) in groups.withIndex()) {
            val t = g[0].s
            val gapPrev = if (i > 0) t - groups[i - 1][0].s else 1e9
            val gapNext = if (i < groups.size - 1) groups[i + 1][0].s - t else 1e9
            val cap = 0.4 * min(gapPrev, gapNext)
            val chordShift = (rnd.nextDouble() * 2 - 1) * min(intensity * 25.0, cap)
            for (n in g) {
                val spread = (rnd.nextDouble() * 2 - 1) * min(intensity * 4.0, cap / 2)
                val sh = max(chordShift + spread, -n.s)
                n.s += sh; n.e += sh
            }
        }
    }

    /** Slow bounded timing wander applied as a displacement of song time (max slope ~0.04 -> monotonic). */
    private fun jitter(ns: List<N>, pedal: List<DoubleArray>, intensity: Double, rnd: java.util.Random) {
        val ph1 = rnd.nextDouble() * 2 * PI
        val ph2 = rnd.nextDouble() * 2 * PI
        val amp = 40.0 * intensity
        fun d(t: Double) = amp * (0.6 * sin(2 * PI * t / 5000.0 + ph1) + 0.4 * sin(2 * PI * t / 11000.0 + ph2))
        for (n in ns) { n.s = max(0.0, n.s + d(n.s)); n.e = max(n.s, n.e + d(n.e)) }
        for (p in pedal) p[0] = max(0.0, p[0] + d(p[0]))
    }

    /** A key can only be down once: merge duplicates, release before the next strike of the same pitch. */
    private fun fixSamePitch(ns: List<N>) {
        for (n in ns) n.e = max(n.e, n.s + MIN_HOLD_MS)
        for ((_, list) in ns.groupBy { it.p }) {
            val l = list.sortedBy { it.s }
            var cur = l[0]
            for (k in 1 until l.size) {
                val nx = l[k]
                if (nx.s - cur.s < 1.0) { cur.e = max(cur.e, nx.e); nx.dead = true; continue }
                val gap = min(REPEAT_GAP_MS, (nx.s - cur.s) / 2)
                if (cur.e > nx.s - gap) cur.e = nx.s - gap
                cur = nx
            }
        }
    }
}
