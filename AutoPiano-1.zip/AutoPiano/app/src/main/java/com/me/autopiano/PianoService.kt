package com.me.autopiano

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.app.AlertDialog
import android.content.Context
import android.content.ContextThemeWrapper
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.*
import kotlinx.coroutines.*
import java.io.File
import kotlin.coroutines.resume
import kotlin.math.max

class Held(val id: Int, val x: Float, val y: Float, var startPos: Double, var endPos: Double) {
    var stroke: StrokeDescription? = null
    var startWall = 0L
    var code = 0
    var shift = false
}

class PianoService : AccessibilityService() {
    companion object {
        var instance: PianoService? = null
        const val SLICE = 60L      // ms per gesture chunk (held notes are chained across chunks)
        const val MIN_HOLD = 90L   // a key is never held shorter than this -> no "1ms tap" cut-offs
        fun folder(c: Context) = File(c.getExternalFilesDir(null), "midi").apply { mkdirs() }
    }

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var wm: WindowManager
    private lateinit var ctx: Context
    private val prefs by lazy { getSharedPreferences("cfg", MODE_PRIVATE) }
    private val hid by lazy { Hid(this) }
    private var panel: View? = null
    private var song: Song? = null
    private var posMs = 0.0
    @Volatile private var playing = false
    private var running = false
    private var job: Job? = null
    private var tempo = 1.0
    private var jit = 0.0
    private var human = true
    private var pedalOn = false
    private var k88 = false
    private var kb = false
    private var dragging = false
    private val held = ArrayList<Held>()
    private lateinit var fileBtn: Button
    private lateinit var playBtn: Button
    private lateinit var posBar: SeekBar
    private lateinit var posTxt: TextView

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        ctx = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault)
        human = prefs.getBoolean("human", true); pedalOn = prefs.getBoolean("pedal", false)
        k88 = prefs.getBoolean("k88", false); kb = prefs.getBoolean("kb", false)
        showPanel()
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean {
        instance = null; playing = false
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null
        return super.onUnbind(i)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun fmt(ms: Double): String { val s = (ms / 1000).toInt(); return "%d:%02d".format(s / 60, s % 60) }

    // ---------------- UI ----------------
    fun showPanel() {
        if (panel != null) return
        val dn = resources.displayMetrics.density
        fun d(v: Int) = (v * dn).toInt()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(d(10), d(6), d(10), d(8))
            background = GradientDrawable().apply { setColor(0xE6202028.toInt()); cornerRadius = d(14).toFloat() }
        }
        val lp = WindowManager.LayoutParams(d(280), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = d(10); y = d(10) }
        val body = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val sv = ScrollView(ctx).apply { addView(body) }
        fun label(s: String) = TextView(ctx).apply { text = s; setTextColor(Color.WHITE); textSize = 12f }
        fun btn(s: String, f: () -> Unit) = Button(ctx).apply { text = s; isAllCaps = false; setOnClickListener { f() } }
        fun slider(name: String, lo: Int, hi: Int, init: Int, f: (Int) -> String, on: (Int) -> Unit) {
            val t = label(name + f(init))
            val sb = SeekBar(ctx).apply {
                max = hi - lo; progress = init - lo
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { t.text = name + f(p + lo); on(p + lo) }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            body.addView(t); body.addView(sb)
        }
        fun sw(name: String, init: Boolean, on: (Boolean) -> Unit) = body.addView(Switch(ctx).apply {
            text = name; setTextColor(Color.WHITE); isChecked = init; setOnCheckedChangeListener { _, c -> on(c) }
        })

        // header (drag me) + collapse
        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("🎹 Auto Piano  (drag)").apply { textSize = 14f }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(btn("–") { sv.visibility = if (sv.visibility == View.VISIBLE) View.GONE else View.VISIBLE })
        header.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_DOWN) { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                else if (e.action == MotionEvent.ACTION_MOVE) {
                    lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt(); wm.updateViewLayout(root, lp)
                }
                return true
            }
        })
        root.addView(header)
        root.addView(sv, LinearLayout.LayoutParams(-1, d(230)))

        fileBtn = btn("📂 Choose MIDI…") { chooseFile() }
        body.addView(fileBtn)
        val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        playBtn = btn("▶ Play") { if (playing) playing = false else play() }
        row.addView(playBtn, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("■ Stop") { scope.launch { playing = false; job?.join(); posMs = 0.0; updatePos() } }, LinearLayout.LayoutParams(0, -2, 1f))
        body.addView(row)
        posTxt = label("0:00 / 0:00"); body.addView(posTxt)
        posBar = SeekBar(ctx).apply {
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    if (u) { val len = song?.len ?: 0.0; posMs = p / 1000.0 * len; posTxt.text = "${fmt(posMs)} / ${fmt(len)}" }
                }
                override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
                override fun onStopTrackingTouch(s: SeekBar?) {
                    dragging = false
                    if (playing) scope.launch { playing = false; job?.join(); play() }
                }
            })
        }
        body.addView(posBar)
        slider("Tempo ", 25, 200, 100, { "$it%" }) { tempo = it / 100.0 }
        slider("Tempo jitter ", 0, 15, 3, { "±$it%" }) { jit = it / 100.0 }
        jit = 0.03
        sw("Humanizer (timing + hold)", human) { human = it; prefs.edit().putBoolean("human", it).apply() }
        sw("Pedal (follows MIDI)", pedalOn) { pedalOn = it; prefs.edit().putBoolean("pedal", it).apply() }
        sw("88 keys (off = 61)", k88) { k88 = it; prefs.edit().putBoolean("k88", it).apply() }
        sw("Keyboard mode (off = touch)", kb) {
            kb = it; prefs.edit().putBoolean("kb", it).apply()
            if (it) try { hid.start(); toast("Pair 'AutoPiano' from the other device") } catch (e: Exception) { toast("Allow Bluetooth permission in the app") }
        }
        body.addView(btn("🎯 Calibrate keys + pedal (touch mode)") { calibrate() })
        wm.addView(root, lp); panel = root
    }

    private fun chooseFile() {
        val fs = folder(this).listFiles { f -> f.extension.lowercase() in listOf("mid", "midi") }?.sortedBy { it.name.lowercase() } ?: emptyList()
        if (fs.isEmpty()) { toast("No MIDI files. Import them in the app first."); return }
        val dlg = AlertDialog.Builder(ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_Alert))
            .setTitle("Pick a song").setItems(fs.map { it.name }.toTypedArray()) { _, i -> load(fs[i]) }.create()
        dlg.window?.setType(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        dlg.show()
    }

    private fun load(f: File) {
        scope.launch {
            playing = false; job?.join()
            try {
                song = withContext(Dispatchers.Default) { Midi.parse(f.readBytes()) }
                posMs = 0.0; fileBtn.text = "📂 ${f.nameWithoutExtension}"; updatePos()
            } catch (e: Exception) { toast("Can't read MIDI: ${e.message}") }
        }
    }

    private fun updatePos() {
        val len = song?.len ?: 0.0
        if (!dragging) posBar.progress = if (len > 0) (posMs / len * 1000).toInt().coerceIn(0, 1000) else 0
        posTxt.text = "${fmt(posMs)} / ${fmt(len)}"
    }

    // ---------------- calibration ----------------
    private val wide get() = k88 && !kb
    private val mode get() = if (wide) 88 else 61
    private fun calibrated() = prefs.contains("px_$mode")

    private fun calibrate() {
        val steps = listOf("Tap the LEFTMOST white key", "Tap the RIGHTMOST white key", "Tap any BLACK key", "Tap the PEDAL button")
        val pts = ArrayList<Pair<Float, Float>>()
        val v = FrameLayout(ctx).apply { setBackgroundColor(0x66000000) }
        val lab = TextView(ctx).apply { text = "[$mode keys] ${steps[0]}"; textSize = 20f; setTextColor(Color.YELLOW); gravity = Gravity.CENTER; setPadding(20, 80, 20, 20) }
        v.addView(lab, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                pts.add(e.rawX to e.rawY)
                if (pts.size == 4) {
                    val m = mode
                    prefs.edit().putFloat("x0_$m", pts[0].first).putFloat("y0_$m", pts[0].second)
                        .putFloat("x1_$m", pts[1].first).putFloat("y1_$m", pts[1].second)
                        .putFloat("by_$m", pts[2].second).putFloat("px_$m", pts[3].first).putFloat("py_$m", pts[3].second).apply()
                    wm.removeView(v); toast("Calibrated for $m keys ✔")
                } else lab.text = "[$mode keys] ${steps[pts.size]}"
            }
            true
        }
        val lp = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(v, lp)
    }

    // ---------------- note -> key mapping ----------------
    private val W = intArrayOf(0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6)
    private fun isSharp(n: Int) = when (n % 12) { 1, 3, 6, 8, 10 -> true else -> false }
    private fun lo() = if (wide) 21 else 36
    private fun fold(n0: Int): Int { var n = n0; val l = lo(); val h = if (wide) 108 else 96; while (n < l) n += 12; while (n > h) n -= 12; return n }
    private fun wIdx(n: Int) = (n / 12) * 7 + W[n % 12] - ((lo() / 12) * 7 + W[lo() % 12])

    private fun pt(n: Int): Pair<Float, Float> {
        val m = mode; val x0 = prefs.getFloat("x0_$m", 0f); val x1 = prefs.getFloat("x1_$m", 0f)
        val step = (x1 - x0) / ((if (wide) 52 else 36) - 1)
        val w = wIdx(n)
        return if (isSharp(n)) (x0 + (w + 0.5f) * step) to prefs.getFloat("by_$m", 0f)
        else (x0 + w * step) to ((prefs.getFloat("y0_$m", 0f) + prefs.getFloat("y1_$m", 0f)) / 2)
    }

    private fun enqueue(nt: Note, out: MutableList<Held>) {
        val k = fold(nt.key)
        val jt = if (human) Math.random() * 14 else 0.0              // onset jitter (ms)
        val ext = if (human) 1.0 + Math.random() * 0.06 else 1.0     // only ever LONGER, never cut short
        val s = nt.t + jt
        val h = if (kb) {
            val c = "1234567890qwertyuiopasdfghjklzxcvbnm"[wIdx(k)]
            val code = if (c == '0') 0x27 else if (c.isDigit()) 0x1E + (c - '1') else 0x04 + (c - 'a')
            Held(k, 0f, 0f, s, s + nt.dur * ext).also { it.code = code; it.shift = isSharp(k) }
        } else { val (x, y) = pt(k); Held(k, x, y, s, s + nt.dur * ext) }
        out.add(h)
    }

    private fun addPedal(pd: Pedal, out: MutableList<Held>) {
        val m = mode
        out.add(Held(-1, if (kb) 0f else prefs.getFloat("px_$m", 0f), if (kb) 0f else prefs.getFloat("py_$m", 0f), pd.t, pd.t + pd.dur).also { it.code = 0x2C })
    }

    // ---------------- playback ----------------
    private fun play() {
        if (running) return
        if (song == null) { toast("Pick a MIDI first"); return }
        if (!kb && !calibrated()) { toast("Calibrate first"); return }
        if (kb && !hid.connected) { toast("Keyboard not connected to a device yet"); return }
        playing = true; playBtn.text = "⏸ Pause"
        job = scope.launch {
            running = true
            try { if (kb) kbLoop() else touchLoop() }
            catch (e: Exception) { toast("Error: ${e.message}") }
            finally { running = false; playing = false; playBtn.text = "▶ Play"; updatePos() }
        }
    }

    private suspend fun dispatch(g: GestureDescription): Boolean = suspendCancellableCoroutine { c ->
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (c.isActive) c.resume(true) }
            override fun onCancelled(d: GestureDescription?) { if (c.isActive) c.resume(false) }
        }, null)
        if (!ok && c.isActive) c.resume(false)
    }

    private suspend fun releaseTouch() {
        if (held.isEmpty()) return
        val gb = GestureDescription.Builder()
        held.take(GestureDescription.getMaxStrokeCount()).forEach { h ->
            gb.addStroke(h.stroke!!.continueStroke(Path().apply { moveTo(h.x, h.y) }, 0, 20, false))
        }
        dispatch(gb.build()); held.clear()
    }

    /**
     * Touch engine. Every key is ONE continuous finger-down that is chained across 60ms gesture
     * chunks (willContinue), so holds last exactly as long as the MIDI note, pause/tempo work live,
     * and nothing gets cut by the next gesture. Android allows max 10 fingers at once (= 10 notes).
     */
    private suspend fun touchLoop() {
        val s = song ?: return
        val n = s.notes; val p = s.pedals
        var i = n.indexOfFirst { it.t >= posMs }.let { if (it < 0) n.size else it }
        var pi = p.indexOfFirst { it.t >= posMs }.let { if (it < 0) p.size else it }
        val pending = ArrayList<Held>()
        var last = SystemClock.uptimeMillis(); var drift = 1.0; var target = 1.0; var nextT = 0L; var uiAt = 0L
        var finished = false
        val maxS = GestureDescription.getMaxStrokeCount()
        held.clear()
        while (playing) {
            val w0 = SystemClock.uptimeMillis()
            if (w0 >= nextT) { target = 1.0 + (Math.random() * 2 - 1) * jit; nextT = w0 + 1000 + (Math.random() * 1500).toLong() }
            drift += (target - drift) * 0.05
            val rate = tempo * drift
            posMs += (w0 - last) * rate; last = w0
            if (w0 - uiAt > 250) { uiAt = w0; updatePos() }
            val look = posMs + SLICE * rate
            while (i < n.size && n[i].t < look) enqueue(n[i++], pending)
            while (pi < p.size && p[pi].t < look) { if (pedalOn) addPedal(p[pi], pending); pi++ }

            val strokes = ArrayList<StrokeDescription>(); val rel = ArrayList<Held>(); val st = ArrayList<Held>()
            for (h in held) {
                val path = Path().apply { moveTo(h.x, h.y) }
                val rw = max(w0 + ((h.endPos - posMs) / rate).toLong(), h.startWall + MIN_HOLD)
                if (rw <= w0 + SLICE) { strokes.add(h.stroke!!.continueStroke(path, 0, max(1L, rw - w0), false)); rel.add(h) }
                else { val ns = h.stroke!!.continueStroke(path, 0, SLICE, true); h.stroke = ns; strokes.add(ns) }
            }
            val it = pending.iterator()
            while (it.hasNext() && strokes.size < maxS) {
                val h = it.next()
                if (h.startPos >= look) continue
                val cur = held.firstOrNull { x -> x.id == h.id }
                if (cur != null) { if (cur.endPos > posMs) cur.endPos = posMs; continue }
                val off = max(0L, ((h.startPos - posMs) / rate).toLong()).coerceAtMost(SLICE - 5)
                h.startWall = w0 + off
                h.stroke = StrokeDescription(Path().apply { moveTo(h.x, h.y) }, off, max(1L, SLICE - off), true)
                strokes.add(h.stroke!!); st.add(h); it.remove()
            }
            if (strokes.isEmpty()) {
                if (i >= n.size && pi >= p.size && pending.isEmpty() && held.isEmpty()) { finished = true; break }
                delay(5); continue
            }
            val gb = GestureDescription.Builder(); strokes.forEach { gb.addStroke(it) }
            if (dispatch(gb.build())) { held.removeAll(rel); held.addAll(st) } else held.clear()
        }
        releaseTouch()
        if (finished) posMs = 0.0
    }

    /** Keyboard engine: same scheduling, but sends HID key down/up to the paired device. */
    private suspend fun kbLoop() {
        val s = song ?: return
        val n = s.notes; val p = s.pedals
        var i = n.indexOfFirst { it.t >= posMs }.let { if (it < 0) n.size else it }
        var pi = p.indexOfFirst { it.t >= posMs }.let { if (it < 0) p.size else it }
        val pending = ArrayList<Held>()
        var last = SystemClock.uptimeMillis(); var drift = 1.0; var target = 1.0; var nextT = 0L; var uiAt = 0L
        var finished = false
        held.clear()
        while (playing) {
            val w = SystemClock.uptimeMillis()
            if (w >= nextT) { target = 1.0 + (Math.random() * 2 - 1) * jit; nextT = w + 1000 + (Math.random() * 1500).toLong() }
            drift += (target - drift) * 0.05
            val rate = tempo * drift
            posMs += (w - last) * rate; last = w
            if (w - uiAt > 250) { uiAt = w; updatePos() }
            while (i < n.size && n[i].t <= posMs) enqueue(n[i++], pending)
            while (pi < p.size && p[pi].t <= posMs) { if (pedalOn) addPedal(p[pi], pending); pi++ }
            val it = pending.iterator()
            while (it.hasNext()) {
                val h = it.next()
                if (h.startPos > posMs) continue
                val cur = held.firstOrNull { x -> x.id == h.id }
                if (cur != null) { hid.key(cur.code, cur.shift, false); held.remove(cur) }
                hid.key(h.code, h.shift, true); h.startWall = w; held.add(h); it.remove()
            }
            val hi = held.iterator()
            while (hi.hasNext()) {
                val h = hi.next()
                if (h.endPos <= posMs && w >= h.startWall + MIN_HOLD) { hid.key(h.code, h.shift, false); hi.remove() }
            }
            if (i >= n.size && pi >= p.size && pending.isEmpty() && held.isEmpty()) { finished = true; break }
            delay(2)
        }
        hid.releaseAll(); held.clear()
        if (finished) posMs = 0.0
    }
}
