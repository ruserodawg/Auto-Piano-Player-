package app.autopiano

import app.autopiano.core.KeySink
import app.autopiano.core.PianoMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/** Picks touch or keyboard output per the current mode setting. */
class RouterSink(private val touch: KeySink, private val keys: KeySink) : KeySink {
    private fun s() = if (Engine.mode() == 1) keys else touch
    override fun down(pitch: Int) = s().down(pitch)
    override fun up(pitch: Int) = s().up(pitch)
    override fun pedal(down: Boolean) = s().pedal(down)
    override fun downIn(pitch: Int, delayMs: Long) = s().downIn(pitch, delayMs)
    override fun upIn(pitch: Int, delayMs: Long) = s().upIn(pitch, delayMs)
    override fun pedalIn(down: Boolean, delayMs: Long) = s().pedalIn(down, delayMs)
    override fun cancelPending() { s().cancelPending() }
    override fun nextEventIn(ms: Long) { s().nextEventIn(ms) }
}

/**
 * Real key-down / key-up events through Shizuku. Events arrive from the player slightly early with an exact
 * delay and are fired on a dedicated thread at the right moment, in order. Sharps are Shift + the natural key
 * (standard Virtual Piano layout, C2..C7). The pedal is the Space key, or a held touch on the pedal point.
 */
class KeyboardSink : KeySink {
    private companion object { const val PRESS = 0; const val RELEASE = 1 }

    private class Pending(val kind: Int, val action: (IKeyInjector) -> Unit) { var future: ScheduledFuture<*>? = null }

    private val exec = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "autopiano-keys").apply { isDaemon = true; priority = Thread.MAX_PRIORITY }
    }
    private val pending = ArrayList<Pending>()

    private fun svc(): IKeyInjector =
        ShizukuKeys.service() ?: throw IllegalStateException(ShizukuKeys.problem())

    private fun fail(e: Throwable) {
        Engine.main.post { Engine.player.stop(); Engine.toast(e.message ?: e.toString()) }
    }

    private fun fire(p: Pending) {
        try { p.action(svc()) } catch (e: Throwable) { fail(e) }
        finally { synchronized(pending) { pending.remove(p) } }
    }

    private fun schedule(kind: Int, delayMs: Long, action: (IKeyInjector) -> Unit) {
        svc()                                    // fail fast with a readable message
        val p = Pending(kind, action)
        synchronized(pending) {
            pending.add(p)
            p.future = exec.schedule(Runnable { fire(p) }, maxOf(0L, delayMs), TimeUnit.MILLISECONDS)
        }
    }

    private fun keyOf(pitch: Int): Pair<Int, Boolean> {
        val s = PianoMap.stroke(pitch)
        return PianoMap.androidKeyCode(s.key) to s.shift
    }

    override fun down(pitch: Int) = downIn(pitch, 0)
    override fun up(pitch: Int) = upIn(pitch, 0)
    override fun pedal(down: Boolean) = pedalIn(down, 0)

    override fun downIn(pitch: Int, delayMs: Long) {
        val (code, shift) = keyOf(pitch)
        schedule(PRESS, delayMs) { it.key(code, true, shift) }
    }

    override fun upIn(pitch: Int, delayMs: Long) {
        val (code, shift) = keyOf(pitch)
        schedule(RELEASE, delayMs) { it.key(code, false, shift) }
    }

    override fun pedalIn(down: Boolean, delayMs: Long) {
        val kind = if (down) PRESS else RELEASE
        if (Engine.getInt("kpedal", 0) == 1) {
            val p = Engine.calibration()?.pedal() ?: return          // touch pedal: needs the pedal point from Align piano
            schedule(kind, delayMs) { it.touch(p.x, p.y, down) }
        } else {
            schedule(kind, delayMs) { it.key(62, down, false) }      // 62 = KEYCODE_SPACE
        }
    }

    /** Drop presses that haven't happened yet; releases stay (made immediate) so nothing can stick. */
    override fun cancelPending() {
        synchronized(pending) {
            for (p in ArrayList(pending)) {
                val f = p.future ?: continue
                if (f.cancel(false)) {
                    pending.remove(p)
                    if (p.kind == RELEASE) {
                        val q = Pending(RELEASE, p.action)
                        pending.add(q)
                        q.future = exec.schedule(Runnable { fire(q) }, 0L, TimeUnit.MILLISECONDS)
                    }
                }
            }
        }
    }
}
