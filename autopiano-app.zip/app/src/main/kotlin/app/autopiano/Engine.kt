package app.autopiano

import android.content.Context
import android.content.SharedPreferences
import android.graphics.PointF
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.widget.Toast
import app.autopiano.core.MidiParser
import app.autopiano.core.Player
import app.autopiano.core.Settings
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList

/** Process-wide singleton: one Player, prefs, MIDI library. Shared by the activity and the overlay. */
object Engine {
    private lateinit var app: Context
    private lateinit var prefs: SharedPreferences
    val main = Handler(Looper.getMainLooper())
    val player = Player(TouchSink())
    val listeners = CopyOnWriteArrayList<() -> Unit>()
    @Volatile var loading = false
    @Volatile var hasSong = false
    @Volatile private var calCache: Calibration? = null

    fun init(c: Context) {
        if (::app.isInitialized) return
        app = c.applicationContext
        prefs = app.getSharedPreferences("autopiano", Context.MODE_PRIVATE)
        player.onState = { notifyUi() }
        player.onError = { e -> toast(e.message ?: e.toString()); notifyUi() }
        player.setTempo(prefs.getInt("tempo", 100) / 100.0)
        applySettings()
        val saved = prefs.getString("file", null)
        files().firstOrNull { it.name == saved }?.let { select(it) }
    }

    fun notifyUi() { main.post { listeners.forEach { it() } } }
    fun toast(msg: String) { main.post { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() } }

    // ---- prefs ----
    fun getBool(k: String, def: Boolean) = prefs.getBoolean(k, def)
    fun setBool(k: String, v: Boolean) { prefs.edit().putBoolean(k, v).apply() }
    fun getInt(k: String, def: Int) = prefs.getInt(k, def)
    fun setInt(k: String, v: Int) { prefs.edit().putInt(k, v).apply() }
    fun is88() = prefs.getBoolean("is88", false)
    fun setIs88(v: Boolean) { setBool("is88", v); calCache = null; applySettings() }

    fun settings(): Settings {
        val big = is88()
        return Settings(
            low = if (big) 21 else 36, high = if (big) 108 else 96,
            humanize = getBool("human", false), humanIntensity = getInt("hInt", 30) / 100.0,
            tempoJitter = getBool("jitter", false), jitterIntensity = getInt("jInt", 30) / 100.0,
            followMidiPedal = getBool("follow", true),
            arpMs = getInt("arp", 10).toDouble(), maxVoices = 9   // touch: 10 strokes max, 1 kept for the pedal
        )
    }

    fun applySettings() = player.configure(settings())

    fun setTempoPercent(p: Int) { setInt("tempo", p); player.setTempo(p / 100.0) }

    // ---- touch calibration: 4 tapped points (lowest white, highest white, black, pedal), per 61/88 mode ----
    private fun ck() = if (is88()) "c88" else "c61"

    fun calibrationPoints(): Array<PointF?> {
        val k = ck()
        return Array(4) { i ->
            if (prefs.contains("$k.p${i}x")) PointF(prefs.getFloat("$k.p${i}x", 0f), prefs.getFloat("$k.p${i}y", 0f))
            else null
        }
    }

    fun calibration(): Calibration? {
        calCache?.let { return it }
        val p = calibrationPoints()
        val a = p[0]; val b = p[1]; val bk = p[2]
        if (a == null || b == null || bk == null) return null
        val s = settings()
        val c = Calibration(s.low, s.high, a.x, b.x, (a.y + b.y) / 2, bk.y, p[3]?.x ?: -1f, p[3]?.y ?: -1f)
        calCache = c
        return c
    }

    fun saveCalibration(p: Array<PointF?>) {
        val k = ck(); val e = prefs.edit()
        for (i in 0..3) {
            val q = p[i]
            if (q == null) { e.remove("$k.p${i}x"); e.remove("$k.p${i}y") }
            else { e.putFloat("$k.p${i}x", q.x); e.putFloat("$k.p${i}y", q.y) }
        }
        e.apply(); calCache = null; notifyUi()
    }

    // ---- library ----
    fun dir(): File = File(app.getExternalFilesDir(null) ?: app.filesDir, "midi").apply { mkdirs() }

    fun files(): List<File> =
        dir().listFiles { f -> f.extension.lowercase() in setOf("mid", "midi") }
            ?.sortedBy { it.name.lowercase() } ?: emptyList()

    fun currentName(): String? = prefs.getString("file", null)

    fun select(f: File) {
        prefs.edit().putString("file", f.name).apply()
        loading = true; notifyUi()
        Thread {
            try {
                val song = MidiParser.parse(f.readBytes())
                player.load(song)
                hasSong = true
            } catch (e: Exception) {
                hasSong = false
                toast("Can't read ${f.name}: ${e.message}")
            }
            loading = false; notifyUi()
        }.start()
    }

    fun cycle(delta: Int) {
        val l = files()
        if (l.isEmpty()) return
        val i = l.indexOfFirst { it.name == currentName() }
        select(l[((if (i < 0) 0 else i) + delta + l.size) % l.size])
    }

    fun delete(f: File) {
        if (f.name == currentName()) { player.stop(); hasSong = false; prefs.edit().remove("file").apply() }
        f.delete(); notifyUi()
    }

    fun importUri(u: Uri) {
        try {
            var name = "imported.mid"
            app.contentResolver.query(u, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i)
            }
            name = name.replace('/', '_')
            if (!name.lowercase().let { it.endsWith(".mid") || it.endsWith(".midi") }) name += ".mid"
            app.contentResolver.openInputStream(u)!!.use { ins ->
                File(dir(), name).outputStream().use { ins.copyTo(it) }
            }
        } catch (e: Exception) { toast("Import failed: ${e.message}") }
        notifyUi()
    }

    fun play(c: Context) {
        if (!hasSong) { toast("Pick a MIDI file first"); return }
        PlayerService.ensure(c)
        player.play()
    }
}
