package app.autopiano

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class TouchAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: TouchAccessibilityService? = null }

    val injector: TouchInjector by lazy { TouchInjector(this) }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}

/**
 * Holds keys with chained touch strokes (Android needs a stroke's length up front).
 *
 * The player sends each event slightly early with an exact delay. All events that fall inside one gesture
 * window become strokes with exact start/end offsets, so a chord is ONE gesture (not one note per gesture)
 * and its notes start together (or on the exact strum offsets). Held keys are chained into the next gesture.
 *
 * - Events are kept in time order and never dropped; a note released before its press finished still gets
 *   a full short touch (MIN_TOUCH).
 * - A gesture ends just before the next unsent event (hint from the player), up to MAX_SEG long.
 * - A watchdog frees the injector if Android never reports a gesture as finished.
 */
class TouchInjector(private val svc: AccessibilityService) {
    companion object { const val PEDAL = -1 }

    private class Ev(val key: Int, val down: Boolean, val atNs: Long)

    @Volatile var cal: Calibration? = null
    @Volatile var cancelled = 0
    @Volatile var failed = 0
    val maxStrokes: Int = GestureDescription.getMaxStrokeCount()

    private val main = Handler(Looper.getMainLooper())
    private val lock = Any()
    private val active = HashMap<Int, GestureDescription.StrokeDescription>()
    private val queue = ArrayList<Ev>()                       // always sorted by atNs
    private var busy = false
    private var busySince = 0L
    @Volatile private var nextEventNs = 0L
    private val minSeg = 20L
    private val maxSeg = 80L
    private val minTouch = 35L

    fun nextEventIn(ms: Long) { nextEventNs = System.nanoTime() + ms * 1_000_000L }

    private fun enqueue(key: Int, down: Boolean, delayMs: Long) {
        val at = System.nanoTime() + delayMs * 1_000_000L
        synchronized(lock) {
            var i = queue.size
            while (i > 0 && queue[i - 1].atNs > at) i--
            queue.add(i, Ev(key, down, at))
        }
        main.post { pump() }
    }

    fun down(key: Int, delayMs: Long) { enqueue(key, true, delayMs) }
    fun up(key: Int, delayMs: Long) { enqueue(key, false, delayMs) }
    fun pedal(on: Boolean, delayMs: Long) { if (on) down(PEDAL, delayMs) else up(PEDAL, delayMs) }

    /** Drop presses that have not happened yet; releases stay (made immediate) so nothing can stick. */
    fun cancelPending() {
        synchronized(lock) {
            val now = System.nanoTime()
            val ups = queue.filter { !it.down }.map { Ev(it.key, false, now) }
            queue.clear(); queue.addAll(ups)
        }
        main.post { pump() }
    }

    private fun path(k: Int, c: Calibration): Path? {
        val p = (if (k == PEDAL) c.pedal() else c.point(k)) ?: return null
        return Path().apply { moveTo(p.x, p.y) }
    }

    private fun pump() {
        val c = cal
        val strokes = ArrayList<GestureDescription.StrokeDescription>()
        val next = HashMap<Int, GestureDescription.StrokeDescription>()
        synchronized(lock) {
            val now = System.nanoTime()
            if (busy) {
                if (now - busySince > 1_000_000_000L) { busy = false; active.clear() }   // watchdog
                else return
            }
            if (c == null) { active.clear(); queue.clear(); return }
            if (queue.isEmpty() && active.isEmpty()) return

            val cur = HashMap<Int, Long>()            // key -> start offset (ms) of its current stroke
            val conts = HashMap<Int, GestureDescription.StrokeDescription>()
            val endOf = HashMap<Int, Long>()          // key -> end offset of its last finished stroke
            var maxEnd = 0L
            var lastOff = 0L
            for ((k, sd) in active) {
                if (path(k, c) == null) continue
                cur[k] = 0L; conts[k] = sd
            }

            var i = 0
            while (i < queue.size) {
                val ev = queue[i]
                val off = maxOf(0L, (ev.atNs - now) / 1_000_000L)
                if (off > 100L) break
                if (ev.down) {
                    if (ev.key in cur) { i++; continue }                               // already pressed
                    val e = endOf[ev.key]
                    if (e != null && off < e + 2) break                                // key still touching: next gesture
                    if (strokes.size + cur.size >= maxStrokes) break                   // stroke limit: next gesture
                    if (path(ev.key, c) != null) { cur[ev.key] = off; lastOff = maxOf(lastOff, off) }
                    i++
                } else {
                    val s = cur.remove(ev.key)
                    val p = path(ev.key, c)
                    if (s != null && p != null) {
                        val cont = conts.remove(ev.key)
                        val end: Long
                        if (cont != null) {
                            end = maxOf(off, 1L)
                            strokes.add(cont.continueStroke(p, 0, end, false))
                        } else {
                            end = s + maxOf(off - s, minTouch)
                            strokes.add(GestureDescription.StrokeDescription(p, s, end - s, false))
                        }
                        endOf[ev.key] = end
                        maxEnd = maxOf(maxEnd, end)
                        lastOff = maxOf(lastOff, off)
                    }
                    i++
                }
            }
            repeat(i) { queue.removeAt(0) }

            // Gesture length: until just before the next unsent event, but long enough for everything above.
            val untilNextMs = (nextEventNs - now) / 1_000_000L
            val evTerm = if (i > 0) lastOff + minTouch else 0L
            val g = minOf(250L, maxOf(minSeg, (untilNextMs - 3).coerceIn(minSeg, maxSeg), evTerm, maxEnd))

            for ((k, s) in cur) {
                val p = path(k, c) ?: continue
                val cont = conts[k]
                val st = if (cont != null) cont.continueStroke(p, 0, g, true)
                else GestureDescription.StrokeDescription(p, s, maxOf(1L, g - s), true)
                strokes.add(st); next[k] = st
            }
            if (strokes.isEmpty()) {
                active.clear()
                if (queue.isNotEmpty()) main.postDelayed({ pump() }, maxOf(1L, (queue[0].atNs - now) / 1_000_000L - 5))
                return
            }
            busy = true; busySince = now
        }
        val b = GestureDescription.Builder()
        strokes.forEach { b.addStroke(it) }
        val ok = svc.dispatchGesture(b.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { done(next, true) }
            override fun onCancelled(g: GestureDescription?) { cancelled++; done(next, false) }
        }, main)
        if (!ok) { failed++; synchronized(lock) { busy = false; active.clear() } }
    }

    private fun done(next: Map<Int, GestureDescription.StrokeDescription>, completed: Boolean) {
        synchronized(lock) {
            active.clear()
            if (completed) active.putAll(next)
            busy = false
        }
        pump()
    }
}
