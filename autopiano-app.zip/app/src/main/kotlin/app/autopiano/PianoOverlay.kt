package app.autopiano

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PointF
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot

/**
 * Drag a ghost piano over the real one. Drag the body to move it, yellow dots to resize
 * (corners = both sides, edge dots = one side). The cyan/pink dots show exactly where touches will land.
 */
class PianoOverlay(private val ctx: Context) {
    companion object { private var running: PianoOverlay? = null }

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = ctx.resources.displayMetrics.density
    private var card: View? = null
    private var root: View? = null
    private lateinit var ghost: GhostPianoView
    private lateinit var layout: Layout
    private lateinit var pedalBtn: Button

    private var active = -1          // 0-7 handle, 8 pedal, 9 body
    private var lx = 0f
    private var ly = 0f

    private fun dp(v: Int) = (v * d).toInt()

    private fun params(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun button(t: String, f: () -> Unit) = Button(ctx).apply {
        text = t; textSize = 12f; isAllCaps = false; minWidth = 0; minimumWidth = 0
        setPadding(dp(12), 0, dp(12), 0); setOnClickListener { f() }
    }

    fun start(skipCard: Boolean = false) {
        if (running != null) return
        if (!Settings.canDrawOverlays(ctx)) { Engine.toast("Allow display over other apps first"); return }
        running = this
        if (skipCard) showEditor() else showCard()
    }

    private fun showCard() {
        val tv = TextView(ctx).apply {
            text = "Open the Roblox piano in the orientation you'll play in, then press Begin."
            setTextColor(Color.WHITE); setPadding(dp(8), dp(8), dp(8), dp(4))
        }
        val c = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xEE222222.toInt())
            addView(tv)
            addView(LinearLayout(ctx).apply {
                addView(button("Begin") { removeCard(); showEditor() })
                addView(button("Cancel") { close() })
            })
        }
        val lp = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL)
        lp.x = dp(8); lp.y = dp(40)
        wm.addView(c, lp); card = c
    }

    private fun removeCard() { card?.let { try { wm.removeView(it) } catch (e: Exception) {} }; card = null }

    private fun close() {
        removeCard()
        root?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        root = null
        running = null
    }

    private fun defaultLayout(): Layout {
        val m = ctx.resources.displayMetrics
        return Layout(m.widthPixels * 0.05f, m.heightPixels * 0.55f, m.widthPixels * 0.95f, m.heightPixels * 0.92f, null)
    }

    private fun showEditor() {
        val saved = Engine.layout()
        layout = saved ?: defaultLayout()
        ghost = GhostPianoView(ctx).apply { this.layout = this@PianoOverlay.layout; editable = true }

        val hint = TextView(ctx).apply {
            text = "Drag the piano onto the real keys. Yellow dots resize."
            setTextColor(Color.WHITE); textSize = 14f; setPadding(dp(10), dp(6), dp(10), dp(2))
        }
        pedalBtn = button("") { togglePedal() }
        val row = LinearLayout(ctx).apply {
            addView(button("Done") { save() })
            addView(pedalBtn)
            addView(button("Cancel") { close() })
        }
        updatePedalLabel()
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xCC000000.toInt())
            addView(hint); addView(row)
        }
        val frame = FrameLayout(ctx).apply {
            setBackgroundColor(0x11000000)
            addView(ghost, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(bar, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL))
            setOnTouchListener { _, e -> onTouch(e); true }
        }
        val lp = params(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        wm.addView(frame, lp); root = frame
    }

    private fun updatePedalLabel() { pedalBtn.text = if (layout.pedal == null) "Add pedal" else "Remove pedal" }

    private fun togglePedal() {
        layout.pedal = if (layout.pedal == null) PointF(layout.r - dp(40), layout.t - dp(30)) else null
        updatePedalLabel(); ghost.invalidate()
    }

    private fun hit(x: Float, y: Float): Int {
        val r = 28 * d
        Handles.points(layout).forEachIndexed { i, p -> if (hypot(x - p.x, y - p.y) < r) return i }
        layout.pedal?.let { if (hypot(x - it.x, y - it.y) < r) return 8 }
        return if (x in layout.l..layout.r && y in layout.t..layout.b) 9 else -1
    }

    private fun onTouch(e: MotionEvent) {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> { active = hit(e.rawX, e.rawY); lx = e.rawX; ly = e.rawY }
            MotionEvent.ACTION_MOVE -> if (active >= 0) {
                applyDrag(e.rawX - lx, e.rawY - ly); lx = e.rawX; ly = e.rawY; ghost.invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> active = -1
        }
    }

    private fun applyDrag(dx: Float, dy: Float) {
        val L = layout
        val minW = 120 * d; val minH = 40 * d
        when (active) {
            in 0..7 -> {
                val f = Handles.flags[active]
                if (f[0]) L.l += dx
                if (f[2]) L.r += dx
                if (f[1]) L.t += dy
                if (f[3]) L.b += dy
                if (L.r - L.l < minW) { if (f[0]) L.l = L.r - minW else L.r = L.l + minW }
                if (L.b - L.t < minH) { if (f[1]) L.t = L.b - minH else L.b = L.t + minH }
            }
            8 -> L.pedal?.let { it.x += dx; it.y += dy }
            9 -> { L.l += dx; L.r += dx; L.t += dy; L.b += dy }
        }
    }

    private fun save() {
        Engine.saveLayout(layout)
        Engine.toast("Piano overlay saved (${Engine.orientationName()})")
        close()
    }
}
