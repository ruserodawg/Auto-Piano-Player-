package com.me.autopiano

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.*
import java.io.File

class MainActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        info = TextView(this).apply { textSize = 15f }
        l.addView(info)
        fun btn(t: String, f: () -> Unit) = l.addView(Button(this).apply { text = t; isAllCaps = false; setOnClickListener { f() } })
        btn("1. Enable 'Auto Piano' accessibility service") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2. Import MIDI files into the app folder") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE); putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }, 1)
        }
        btn("3. Show floating panel") {
            val s = PianoService.instance
            if (s == null) Toast.makeText(this, "Enable the accessibility service first", Toast.LENGTH_LONG).show() else s.showPanel()
        }
        btn("Keyboard mode: Bluetooth permission") {
            if (Build.VERSION.SDK_INT >= 31) requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE), 2)
        }
        btn("Keyboard mode: make phone discoverable") {
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300))
        }
        setContentView(ScrollView(this).apply { addView(l) })
    }

    override fun onResume() {
        super.onResume()
        val f = PianoService.folder(this)
        info.text = "MIDI folder:\n${f.absolutePath}\n(${f.listFiles()?.size ?: 0} files)\n\nPick songs from the floating panel — no need to come back here."
    }

    @Deprecated("fine")
    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        if (rq != 1 || rs != RESULT_OK || d == null) return
        val uris = ArrayList<android.net.Uri>()
        d.data?.let { uris.add(it) }
        d.clipData?.let { for (i in 0 until it.itemCount) uris.add(it.getItemAt(i).uri) }
        for (u in uris) {
            var name = "song_${System.currentTimeMillis()}.mid"
            contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) { val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = c.getString(i) }
            }
            contentResolver.openInputStream(u)?.use { ins -> File(PianoService.folder(this), name).outputStream().use { ins.copyTo(it) } }
        }
        onResume()
    }
}
