package app.autopiano

import android.graphics.PointF

/**
 * Touch layout from 4 taps: lowest white key, highest white key, any black key, pedal.
 * White keys are assumed evenly spaced; a black key sits halfway between its neighbours.
 */
class Calibration(
    val low: Int, val high: Int,
    private val leftX: Float, private val rightX: Float,
    private val whiteY: Float, private val blackY: Float,
    private val pedalX: Float, private val pedalY: Float
) {
    private val blackSemis = setOf(1, 3, 6, 8, 10)
    private fun isBlack(p: Int) = (p % 12) in blackSemis
    fun isBlackKey(p: Int) = isBlack(p)
    private val whiteCount = (low..high).count { !isBlack(it) }
    private val step = if (whiteCount > 1) (rightX - leftX) / (whiteCount - 1) else 0f
    private fun whiteIndex(p: Int) = (low until p).count { !isBlack(it) }

    fun point(p: Int): PointF? {
        if (p < low || p > high) return null
        val idx = whiteIndex(p)
        return if (isBlack(p)) PointF(leftX + (idx - 0.5f) * step, blackY)
        else PointF(leftX + idx * step, whiteY)
    }

    fun pedal(): PointF? = if (pedalX >= 0) PointF(pedalX, pedalY) else null
}

/**
 * The ghost piano rectangle you drag over the real keys, in the overlay window's coordinates, plus an optional pedal.
 * White keys are evenly spaced across it; black keys sit on the white-key boundaries.
 * fw / fb = where (as a fraction of the height from the top) the white / black touch rows are - you drag these rows.
 * ox, oy = where the overlay window's origin is on the real screen (handles notches / insets).
 */
class Layout(
    var l: Float, var t: Float, var r: Float, var b: Float, var pedal: PointF?,
    var fw: Float = 0.8f, var fb: Float = 0.3f, var ox: Float = 0f, var oy: Float = 0f
) {
    /** screen = true gives real screen coordinates (for touches); false gives overlay coordinates (for drawing). */
    fun toCalibration(low: Int, high: Int, screen: Boolean = true): Calibration {
        val black = setOf(1, 3, 6, 8, 10)
        val whites = (low..high).count { (it % 12) !in black }
        val ww = (r - l) / whites
        val h = b - t
        val dx = if (screen) ox else 0f
        val dy = if (screen) oy else 0f
        return Calibration(low, high, dx + l + ww / 2, dx + r - ww / 2, dy + t + fw * h, dy + t + fb * h,
            pedal?.let { dx + it.x } ?: -1f, pedal?.let { dy + it.y } ?: -1f)
    }
}
