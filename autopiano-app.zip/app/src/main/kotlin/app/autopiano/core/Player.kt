package app.autopiano.core

/** Output backend (Bluetooth keyboard, touch injector...). Called from the player thread. */
interface KeySink {
    fun down(pitch: Int)
    fun up(pitch: Int)
    fun pedal(down: Boolean)
    /** Called by the player: the next scheduled event is [ms] wall-clock milliseconds away. */
    fun nextEventIn(ms: Long) {}
    /** Same as down/up/pedal but due [delayMs] from now (the player sends events a little early). */
    fun downIn(pitch: Int, delayMs: Long) = down(pitch)
    fun upIn(pitch: Int, delayMs: Long) = up(pitch)
    fun pedalIn(down: Boolean, delayMs: Long) = pedal(down)
    /** Forget events that were sent early but have not happened yet (pause/stop/seek). Early releases must survive. */
    fun cancelPending() {}
}

enum class PlayState { STOPPED, PLAYING, PAUSED }

/**
 * Position is kept in "song milliseconds" (time at 100% tempo). Wall time advances it by
 * elapsed * tempo, so tempo changes affect upcoming notes immediately, and MIDI tempo
 * changes are already baked into song time.
 *
 * Rules:
 *  - Pause/stop/seek/error release every held key and the pedal.
 *  - Resume does not re-strike notes that were mid-hold; the pedal is restored.
 *  - Pedal: if followMidiPedal && song has pedal events -> MIDI controls it, else manual toggle.
 *    The pedal is only physically down while PLAYING.
 */
class Player(
    private val sink: KeySink,
    private val useThread: Boolean = true,
    private val clock: () -> Long = System::nanoTime
) {
    companion object { const val LOOKAHEAD_MS = 40.0 }

    private val lock = Any()
    private var song: Song? = null
    private var settings = Settings()
    private var sched = Schedule(emptyList(), false)
    private var idx = 0
    private var posMs = 0.0
    private var tempo = 1.0
    private var lastNs = 0L
    private var state = PlayState.STOPPED
    private var runId = 0
    private val held = HashSet<Int>()
    private var pedalDown = false
    private var manualPedal = false
    private var midiPedal = false

    @Volatile var onState: ((PlayState) -> Unit)? = null
    @Volatile var onError: ((Throwable) -> Unit)? = null

    // ---- public API -------------------------------------------------------

    fun load(s: Song) {
        synchronized(lock) {
        stopLocked(); song = s; rebuildLocked()
        }
    }

    /** Change range/humanization/jitter/pedal-follow. Releases held notes (brief glitch if mid-song). */
    fun configure(st: Settings) {
        synchronized(lock) {
        integrateLocked(); settings = st
        releaseNotesLocked(); rebuildLocked(); applyPedalLocked()
        }
    }

    fun play() {
        synchronized(lock) {
        if (song == null || state == PlayState.PLAYING) return
        if (idx >= sched.actions.size) { posMs = 0.0; idx = 0; midiPedal = false }
        state = PlayState.PLAYING
        lastNs = clock()
        guard { applyPedalLocked() } ?: return
        onState?.invoke(state)
        if (useThread) startThread()
        }
    }

    fun pause() {
        synchronized(lock) {
        if (state != PlayState.PLAYING) return
        integrateLocked()
        runId++
        state = PlayState.PAUSED
        releaseAllLocked()
            idx = lowerBound(posMs)          // events sent early but not yet heard are replayed on resume
            recomputeMidiPedalLocked()
        onState?.invoke(state)
        }
    }

    fun stop() { synchronized(lock) { stopLocked() } }

    fun restart() { synchronized(lock) { stopLocked(); play() } }

    fun seek(ms: Double) {
        synchronized(lock) {
        integrateLocked()
        releaseNotesLocked()
        posMs = ms.coerceIn(0.0, song?.durationMs ?: 0.0)
        idx = lowerBound(posMs)
        recomputeMidiPedalLocked()
        guard { applyPedalLocked() }
        }
    }

    /** 0.5..2.0 typical. Takes effect immediately. */
    fun setTempo(f: Double) {
        synchronized(lock) {
        integrateLocked(); tempo = f.coerceIn(0.1, 4.0)
        }
    }

    fun setManualPedal(on: Boolean) {
        synchronized(lock) {
        manualPedal = on; guard { applyPedalLocked() }
        }
    }

    fun positionMs(): Double = synchronized(lock) { integrateLocked(); posMs }
    fun cutNotes(): Int = synchronized(lock) { sched.cut }
    fun durationMs(): Double = synchronized(lock) { song?.durationMs ?: 0.0 }
    fun playState(): PlayState = synchronized(lock) { state }
    /** True when the manual pedal toggle is ignored because MIDI controls the pedal. */
    fun pedalIsAuto(): Boolean = synchronized(lock) { settings.followMidiPedal && sched.hasPedal }

    // ---- engine -----------------------------------------------------------

    private fun startThread() {
        val id = ++runId
        Thread({ loop(id) }, "autopiano-player").apply { isDaemon = true; priority = Thread.MAX_PRIORITY; start() }
    }

    private fun loop(id: Int) {
        while (true) {
            var sleep = 1L
            synchronized(lock) {
                if (id != runId || state != PlayState.PLAYING) return
                try {
                    integrateLocked()
                    advanceLocked()
                    if (idx >= sched.actions.size) {
                        // everything has been sent; let the last events (sent up to LOOKAHEAD_MS early) happen first
                        val tail = ((sched.actions.lastOrNull()?.timeMs ?: 0.0) - posMs) / tempo
                        if (tail <= 0.0) { stopLocked(); return }
                        sleep = tail.toLong().coerceIn(1L, 10L)
                    } else {
                        val wait = (sched.actions[idx].timeMs - posMs) / tempo
                        sink.nextEventIn(wait.toLong().coerceAtLeast(0))
                        sleep = (wait - LOOKAHEAD_MS).toLong().coerceIn(1L, 10L)
                    }
                } catch (e: Throwable) { failLocked(e); return }
                Unit
            }
            Thread.sleep(sleep)
        }
    }

    /** Test hook / loop body: dispatch everything due at song time [pos]. */
    internal fun advanceTo(pos: Double) {
        synchronized(lock) {
        posMs = pos; guard { advanceLocked() }
        }
    }

    private fun advanceLocked() {
        val horizon = posMs + LOOKAHEAD_MS * tempo
        while (idx < sched.actions.size && sched.actions[idx].timeMs <= horizon) {
            val a = sched.actions[idx++]
            dispatchLocked(a, ((a.timeMs - posMs) / tempo).toLong().coerceAtLeast(0))
        }
    }

    private fun dispatchLocked(a: Action, delayMs: Long) {
        when (a.kind) {
            Kind.DOWN -> {
                if (!held.add(a.pitch)) sink.upIn(a.pitch, delayMs)   // never double-press
                sink.downIn(a.pitch, delayMs)
            }
            Kind.UP -> if (held.remove(a.pitch)) sink.upIn(a.pitch, delayMs)
            Kind.PEDAL_DOWN -> { midiPedal = true; applyPedalLocked(delayMs) }
            Kind.PEDAL_UP -> { midiPedal = false; applyPedalLocked(delayMs) }
        }
    }

    private fun integrateLocked() {
        if (state == PlayState.PLAYING) {
            val n = clock()
            posMs += (n - lastNs) / 1e6 * tempo
            lastNs = n
        }
    }

    private fun applyPedalLocked(delayMs: Long = 0) {
        val auto = settings.followMidiPedal && sched.hasPedal
        val want = state == PlayState.PLAYING && (if (auto) midiPedal else manualPedal)
        if (want != pedalDown) { pedalDown = want; sink.pedalIn(want, delayMs) }
    }

    private fun rebuildLocked() {
        sched = song?.let { Scheduler.build(it, settings) } ?: Schedule(emptyList(), false)
        idx = lowerBound(posMs)
        recomputeMidiPedalLocked()
    }

    private fun recomputeMidiPedalLocked() {
        midiPedal = false
        for (i in 0 until idx) when (sched.actions[i].kind) {
            Kind.PEDAL_DOWN -> midiPedal = true
            Kind.PEDAL_UP -> midiPedal = false
            else -> {}
        }
    }

    private fun lowerBound(t: Double): Int {
        var lo = 0; var hi = sched.actions.size
        while (lo < hi) { val m = (lo + hi) ushr 1; if (sched.actions[m].timeMs < t) lo = m + 1 else hi = m }
        return lo
    }

    private fun stopLocked() {
        runId++
        releaseAllLocked()
        val changed = state != PlayState.STOPPED
        state = PlayState.STOPPED
        posMs = 0.0; idx = 0; midiPedal = false
        if (changed) onState?.invoke(state)
    }

    private fun releaseNotesLocked() {
        try { sink.cancelPending() } catch (e: Throwable) {}
        val list = held.toList(); held.clear()
        for (p in list) try { sink.up(p) } catch (e: Throwable) {}
    }

    private fun releaseAllLocked() {
        releaseNotesLocked()
        if (pedalDown) { pedalDown = false; try { sink.pedal(false) } catch (e: Throwable) {} }
    }

    private fun failLocked(e: Throwable) {
        runId++
        releaseAllLocked()
        state = PlayState.STOPPED
        onState?.invoke(state)
        onError?.invoke(e)
    }

    /** Runs [block]; on sink failure releases everything, stops, reports, and returns null. */
    private inline fun guard(block: () -> Unit): Unit? =
        try { block(); Unit } catch (e: Throwable) { failLocked(e); null }
}
