package app.autopiano

import android.os.IBinder
import android.os.SystemClock
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyCharacterMap
import android.view.KeyEvent
import android.view.MotionEvent
import java.lang.reflect.Method
import kotlin.system.exitProcess

/**
 * Runs inside Shizuku's privileged (shell) process, where Android allows input injection.
 * Sends real keyboard key-down / key-up events (so notes are truly held) and one touch pointer for the pedal.
 */
class KeyInjectorService : IKeyInjector.Stub() {
    private var im: Any? = null
    private var inject: Method? = null
    private var err: String? = null
    private val held = HashSet<Int>()
    private var touching = false
    private var touchDownTime = 0L
    private var tx = 0f
    private var ty = 0f

    init {
        try {
            val sm = Class.forName("android.os.ServiceManager")
            val binder = sm.getMethod("getService", String::class.java).invoke(null, "input") as IBinder
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            im = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            inject = Class.forName("android.hardware.input.IInputManager")
                .getMethod("injectInputEvent", InputEvent::class.java, Integer.TYPE)
        } catch (e: Throwable) {
            err = "Can't reach Android's input system: $e"
        }
    }

    private fun send(ev: InputEvent) {
        val m = inject ?: throw IllegalStateException(err ?: "input system not ready")
        m.invoke(im, ev, 0)               // 0 = asynchronous injection
    }

    private fun inj(code: Int, action: Int, meta: Int) {
        val t = SystemClock.uptimeMillis()
        send(KeyEvent(t, t, action, code, 0, meta, KeyCharacterMap.VIRTUAL_KEYBOARD, 0, 0, InputDevice.SOURCE_KEYBOARD))
    }

    override fun destroy() { releaseAll(); exitProcess(0) }

    override fun ready(): Boolean = inject != null

    override fun error(): String = err ?: ""

    /** One key event. For sharps, shift is pressed right before and released right after, in one atomic step. */
    override fun key(keyCode: Int, down: Boolean, shift: Boolean) {
        synchronized(this) {
            val meta = if (shift) (KeyEvent.META_SHIFT_ON or KeyEvent.META_SHIFT_LEFT_ON) else 0
            if (shift) inj(KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.ACTION_DOWN, meta)
            inj(keyCode, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, meta)
            if (shift) inj(KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.ACTION_UP, 0)
            if (down) held.add(keyCode) else held.remove(keyCode)
        }
    }

    /** A single held touch pointer, used for an on-screen pedal button. */
    override fun touch(x: Float, y: Float, down: Boolean) {
        synchronized(this) {
            val t = SystemClock.uptimeMillis()
            val ev: MotionEvent
            if (down) {
                touchDownTime = t; touching = true; tx = x; ty = y
                ev = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0)
            } else {
                if (!touching) return
                touching = false
                ev = MotionEvent.obtain(touchDownTime, t, MotionEvent.ACTION_UP, tx, ty, 0)
            }
            ev.source = InputDevice.SOURCE_TOUCHSCREEN
            try { send(ev) } finally { ev.recycle() }
        }
    }

    override fun releaseAll() {
        synchronized(this) {
            for (k in held.toList()) try { inj(k, KeyEvent.ACTION_UP, 0) } catch (e: Throwable) {}
            held.clear()
            if (touching) try { touch(tx, ty, false) } catch (e: Throwable) {}
        }
    }
}
