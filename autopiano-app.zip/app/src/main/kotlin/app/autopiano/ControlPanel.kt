package app.autopiano

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import app.autopiano.core.PlayState

/** Compact transport + tempo + position + toggles. Used on the main screen and in the floating overlay. */
class ControlPanel(ctx: Context) : LinearLayout(ctx) {
    private val fileLabel = label("")
    private val btnPlay = btn("▶") { onPlay() }
    private val timeText = label("0:00/0:00")
    private val tempoText = label("100%")
    private val tempoBar = SeekBar(ctx).apply { max = 150 }
    private val posBar = SeekBar(ctx).apply { max = 1000 }
    private val cbHuman = check("Human") { Engine.setBool("human", it); Engine.applySettings() }
    private val cbJitter = check("Jitter") { Engine.setBool("jitter", it); Engine.applySettings() }
    private val cbPedal = check("Pedal") { Engine.player.setManualPedal(it) }
    private var dragging = false
    private var updating = false

    private val tick = object : Runnable {
        override fun run() { updatePos(); Engine.main.postDelayed(this, 200) }
    }
    private val listener: () -> Unit = { refresh() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(t: String) = TextView(ctx()).apply { text = t; setTextColor(Color.WHITE); textSize = 12f }
    private fun ctx() = context
    private fun btn(t: String, f: () -> Unit) = Button(context).apply {
        text = t; textSize = 13f; isAllCaps = false; minWidth = 0; minimumWidth = 0
        setPadding(dp(10), 0, dp(10), 0); setOnClickListener { f() }
    }
    private fun check(t: String, f: (Boolean) -> Unit) = CheckBox(context).apply {
        text = t; textSize = 12f; setTextColor(Color.WHITE)
        setOnCheckedChangeListener { _, v -> if (!updating) f(v) }
    }
    private fun row(vararg v: View) = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        v.forEach { addView(it) }
    }

    init {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(8), dp(6), dp(8), dp(6))
        setBackgroundColor(0xEE222222.toInt())

        fileLabel.apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE }
        val lp1 = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        addView(row(btn("◀") { Engine.cycle(-1) }, fileLabel.also { it.layoutParams = lp1 }, btn("▶") { Engine.cycle(1) }))
        addView(row(btn("■") { Engine.player.stop() }, btnPlay, btn("⟲") { Engine.player.restart(); }, timeText))
        tempoBar.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        addView(row(label("Tempo "), tempoBar, tempoText))
        addView(posBar)
        addView(row(cbHuman, cbJitter, cbPedal))

        tempoBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tempoText.text = "${50 + p}%"
                if (fromUser) Engine.setTempoPercent(50 + p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        posBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar?) {
                dragging = false
                Engine.player.seek(posBar.progress / 1000.0 * Engine.player.durationMs())
            }
        })
    }

    private fun onPlay() {
        if (Engine.player.playState() == PlayState.PLAYING) Engine.player.pause() else Engine.play(context)
    }

    private fun fmt(ms: Double): String { val s = (ms / 1000).toInt(); return "${s / 60}:${"%02d".format(s % 60)}" }

    private fun updatePos() {
        val dur = Engine.player.durationMs(); val pos = Engine.player.positionMs()
        if (!dragging && dur > 0) posBar.progress = (pos / dur * 1000).toInt().coerceIn(0, 1000)
        timeText.text = " ${fmt(pos)}/${fmt(dur)}"
    }

    private fun refresh() {
        updating = true
        val st = Engine.player.playState()
        btnPlay.text = if (st == PlayState.PLAYING) "⏸" else "▶"
        btnPlay.isEnabled = !Engine.loading
        fileLabel.text = if (Engine.loading) "Loading…" else (Engine.currentName() ?: "(no file)")
        tempoBar.progress = Engine.getInt("tempo", 100) - 50
        cbHuman.isChecked = Engine.getBool("human", false)
        cbJitter.isChecked = Engine.getBool("jitter", false)
        val auto = Engine.player.pedalIsAuto()
        cbPedal.text = if (auto) "Pedal:MIDI" else "Pedal"
        cbPedal.isEnabled = !auto
        updating = false
        updatePos()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        Engine.listeners.add(listener); refresh(); Engine.main.post(tick)
    }

    override fun onDetachedFromWindow() {
        Engine.listeners.remove(listener); Engine.main.removeCallbacks(tick)
        super.onDetachedFromWindow()
    }
}
