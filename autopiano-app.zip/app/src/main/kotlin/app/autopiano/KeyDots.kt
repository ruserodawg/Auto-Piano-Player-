package app.autopiano

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PointF
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/** Resize/move handles of the ghost piano: 0-3 corners, 4-7 edge midpoints. flags = moves (left, top, right, bottom). */
object Handles {
    val flags = arrayOf(
        booleanArrayOf(true, true, false, false), booleanArrayOf(false, true, true, false),
        booleanArrayOf(true, false, false, true), booleanArrayOf(false, false, true, true),
        booleanArrayOf(true, false, false, false), booleanArrayOf(false, false, true, false),
        booleanArrayOf(false, true, false, false), booleanArrayOf(false, false, false, true)
    )
    fun points(l: Layout): List<PointF> {
        val mx = (l.l + l.r) / 2; val my = (l.t + l.b) / 2
        return listOf(
            PointF(l.l, l.t), PointF(l.r, l.t), PointF(l.l, l.b), PointF(l.r, l.b),
            PointF(l.l, my), PointF(l.r, my), PointF(mx, l.t), PointF(mx, l.b)
        )
    }
}

/** Draws the ghost piano (white/black keys), the exact touch dots, and optionally the drag handles. */
class GhostPianoView(ctx: Context) : View(ctx) {
    var layout: Layout? = null
    var editable = false

    private val d = ctx.resources.displayMetrics.density
    private val whiteFill = Paint().apply { color = Color.argb(55, 255, 255, 255) }
    private val blackFill = Paint().apply { color = Color.argb(175, 0, 0, 0) }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(210, 255, 255, 255); style = Paint.Style.STROKE; strokeWidth = 1f * d }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.BLACK; strokeWidth = 1.5f * d }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 11f * d; textAlign = Paint.Align.CENTER
        setShadowLayer(3f * d, 0f, 0f, Color.BLACK)
    }

    private fun dot(c: Canvas, x: Float, y: Float, color: Int, r: Float) {
        fill.color = color
        c.drawCircle(x, y, r, fill); c.drawCircle(x, y, r, outline)
    }

    override fun onDraw(c: Canvas) {
        val L = layout ?: return
        val cal = Engine.calibrationFor(L)
        val h = L.b - L.t
        val keys = cal.low..cal.high
        val whites = keys.count { !cal.isBlackKey(it) }
        val ww = (L.r - L.l) / whites

        c.drawRect(L.l, L.t, L.r, L.b, whiteFill)
        for (i in 0..whites) { val x = L.l + i * ww; c.drawLine(x, L.t, x, L.b, line) }
        c.drawLine(L.l, L.t, L.r, L.t, line); c.drawLine(L.l, L.b, L.r, L.b, line)

        for (p in keys) if (cal.isBlackKey(p)) {
            val pt = cal.point(p) ?: continue
            c.drawRect(pt.x - 0.3f * ww, L.t, pt.x + 0.3f * ww, L.t + 0.62f * h, blackFill)
        }
        for (p in keys) {
            val pt = cal.point(p) ?: continue
            val black = cal.isBlackKey(p)
            dot(c, pt.x, pt.y, if (black) 0xFFFF4081.toInt() else 0xFF00E5FF.toInt(), (if (black) 4f else 5f) * d)
            if (!black && p % 12 == 0) c.drawText("C${p / 12 - 1}", pt.x, L.b - 4 * d, text)
        }
        c.drawText("LOW", L.l + ww / 2, L.b + 16 * d, text)
        c.drawText("HIGH", L.r - ww / 2, L.b + 16 * d, text)
        L.pedal?.let { dot(c, it.x, it.y, Color.YELLOW, 10 * d); c.drawText("PEDAL", it.x, it.y - 16 * d, text) }

        if (editable) {
            for (p in Handles.points(L)) dot(c, p.x, p.y, Color.YELLOW, 10 * d)
        }
    }
}

/** Click-through ghost piano showing where touches will land (toggle from the app or floating panel). */
object KeyDots {
    private var view: View? = null
    private var wm: WindowManager? = null
    private val autoHide = Runnable { hide() }

    fun toggle(ctx: Context) { if (view != null) hide() else show(ctx, 0) }

    fun show(ctx: Context, autoHideMs: Long) {
        hide()
        val app = ctx.applicationContext
        val l = Engine.layout() ?: run { Engine.toast("Align the piano overlay first"); return }
        if (!Settings.canDrawOverlays(app)) { Engine.toast("Allow display over other apps first"); return }
        val w = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val v = GhostPianoView(app).apply { layout = l }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        w.addView(v, lp)
        wm = w; view = v
        if (autoHideMs > 0) Engine.main.postDelayed(autoHide, autoHideMs)
    }

    fun hide() {
        Engine.main.removeCallbacks(autoHide)
        view?.let { try { wm?.removeView(it) } catch (e: Exception) {} }
        view = null
    }
}
