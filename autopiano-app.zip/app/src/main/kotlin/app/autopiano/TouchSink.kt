package app.autopiano

import app.autopiano.core.KeySink

class TouchSink : KeySink {
    private fun inj(): TouchInjector {
        val svc = TouchAccessibilityService.instance
            ?: throw IllegalStateException("Turn on the Auto Piano accessibility service first")
        val cal = Engine.calibration()
            ?: throw IllegalStateException("Align the piano overlay first (Align piano button)")
        svc.injector.cal = cal
        return svc.injector
    }

    override fun down(pitch: Int) { inj().down(pitch, 0) }
    override fun up(pitch: Int) { inj().up(pitch, 0) }
    override fun pedal(down: Boolean) { inj().pedal(down, 0) }
    override fun downIn(pitch: Int, delayMs: Long) { inj().down(pitch, delayMs) }
    override fun upIn(pitch: Int, delayMs: Long) { inj().up(pitch, delayMs) }
    override fun pedalIn(down: Boolean, delayMs: Long) { inj().pedal(down, delayMs) }
    override fun cancelPending() { TouchAccessibilityService.instance?.injector?.cancelPending() }
    override fun nextEventIn(ms: Long) { TouchAccessibilityService.instance?.injector?.nextEventIn(ms) }
}
