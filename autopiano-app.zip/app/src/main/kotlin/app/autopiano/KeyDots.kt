package app.autopiano

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/** Draws a dot at every key position (and the pedal), plus optional numbered markers for tapped points. */
class KeyDotsView(ctx: Context, private val showEnds: Boolean = true) : View(ctx) {
    var cal: Calibration? = null
    var markers: List<Triple<String, Float, Float>> = emptyList()

    private val d = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.BLACK; strokeWidth = 1.5f * d }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.YELLOW; strokeWidth = 3f * d }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 11f * d; textAlign = Paint.Align.CENTER
        setShadowLayer(3f * d, 0f, 0f, Color.BLACK)
    }
    private val markText = Paint(text).apply { textSize = 14f * d; color = Color.YELLOW }

    private fun dot(c: Canvas, x: Float, y: Float, color: Int, r: Float) {
        fill.color = color
        c.drawCircle(x, y, r, fill); c.drawCircle(x, y, r, stroke)
    }

    override fun onDraw(c: Canvas) {
        cal?.let { k ->
            for (p in k.low..k.high) {
                val pt = k.point(p) ?: continue
                val black = k.isBlackKey(p)
                dot(c, pt.x, pt.y, if (black) 0xFFFF4081.toInt() else 0xFF00E5FF.toInt(), (if (black) 5f else 6f) * d)
                if (p % 12 == 0 && !black) c.drawText("C${p / 12 - 1}", pt.x, pt.y - 12 * d, text)
                if (showEnds && (p == k.low || p == k.high)) {
                    c.drawCircle(pt.x, pt.y, 13 * d, ring)
                    c.drawText(if (p == k.low) "LOW" else "HIGH", pt.x, pt.y + 28 * d, text)
                }
            }
            k.pedal()?.let { dot(c, it.x, it.y, Color.YELLOW, 8 * d); c.drawText("PEDAL", it.x, it.y - 14 * d, text) }
        }
        for ((label, x, y) in markers) {
            c.drawCircle(x, y, 16 * d, ring)
            c.drawText(label, x, y - 22 * d, markText)
        }
    }
}

/** Click-through overlay showing the saved key positions. */
object KeyDots {
    private var view: View? = null
    private var wm: WindowManager? = null
    private val autoHide = Runnable { hide() }

    fun toggle(ctx: Context) { if (view != null) hide() else show(ctx, 0) }

    fun show(ctx: Context, autoHideMs: Long) {
        hide()
        val app = ctx.applicationContext
        val cal = Engine.calibration() ?: run { Engine.toast("Calibrate touch positions first"); return }
        if (!Settings.canDrawOverlays(app)) { Engine.toast("Allow display over other apps first"); return }
        val w = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val v = KeyDotsView(app).apply { this.cal = cal }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        w.addView(v, lp)
        wm = w; view = v
        if (autoHideMs > 0) Engine.main.postDelayed(autoHide, autoHideMs)
    }

    fun hide() {
        Engine.main.removeCallbacks(autoHide)
        view?.let { try { wm?.removeView(it) } catch (e: Exception) {} }
        view = null
    }
}
