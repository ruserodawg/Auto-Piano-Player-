package app.autopiano

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Foreground service: keeps playback alive in the background and hosts the floating panel. */
class PlayerService : Service() {
    companion object {
        const val ACTION_SHOW = "app.autopiano.SHOW"
        const val ACTION_STOP = "app.autopiano.STOP"
        private const val CH = "playback"

        fun ensure(c: Context) {
            c.startForegroundService(Intent(c, PlayerService::class.java))
        }
        fun show(c: Context) {
            c.startForegroundService(Intent(c, PlayerService::class.java).setAction(ACTION_SHOW))
        }
        fun quit(c: Context) {
            c.startService(Intent(c, PlayerService::class.java).setAction(ACTION_STOP))
        }
    }

    private var panel: View? = null
    private var wm: WindowManager? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Engine.init(this)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(CH, "Playback", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = Notification.Builder(this, CH)
            .setContentTitle("Auto Piano").setContentText("Player running")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)

        when (intent?.action) {
            ACTION_SHOW -> showPanel()
            ACTION_STOP -> { hidePanel(); Engine.player.stop(); stopSelf() }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        hidePanel(); Engine.player.stop(); super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showPanel() {
        if (panel != null) return
        if (!Settings.canDrawOverlays(this)) { Engine.toast("Allow 'display over other apps' first"); return }
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w

        val body = ControlPanel(this)
        val handle = TextView(this).apply {
            text = "≡ Auto Piano (drag)"; setTextColor(Color.WHITE); textSize = 12f
            setPadding(dp(8), dp(4), dp(8), dp(4))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        fun small(t: String, f: () -> Unit) = Button(this).apply {
            text = t; textSize = 12f; isAllCaps = false; minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
            setPadding(dp(10), dp(2), dp(10), dp(2)); setOnClickListener { f() }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; setBackgroundColor(0xEE111111.toInt())
            gravity = Gravity.CENTER_VERTICAL
            addView(handle)
            addView(small("–") { body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE })
            addView(small("✕") { hidePanel() })
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; addView(header); addView(body)
        }

        val lp = WindowManager.LayoutParams(
            dp(320), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(40) }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt()
                    w.updateViewLayout(root, lp)
                }
            }
            true
        }
        w.addView(root, lp)
        panel = root
    }

    private fun hidePanel() {
        panel?.let { try { wm?.removeView(it) } catch (e: Exception) {} }
        panel = null
    }
}
