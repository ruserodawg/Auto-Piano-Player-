package app.autopiano

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PointF
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min

/**
 * Drag a ghost piano over the real one.
 *  - 1 finger on the body: move.   - 2 fingers: stretch (spread horizontally = wider, vertically = taller).
 *  - Pull any edge or yellow dot to resize that side.
 *  - Drag the cyan "W" row and pink "B" row up/down so they sit on the white keys / black keys.
 *  - "Test" really presses keys through the accessibility service so you can see what lands where.
 */
class PianoOverlay(private val ctx: Context) {
    companion object { private var running: PianoOverlay? = null }

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = ctx.resources.displayMetrics.density
    private var card: View? = null
    private var root: View? = null
    private lateinit var ghost: GhostPianoView
    private lateinit var layout: Layout
    private lateinit var pedalBtn: Button

    private var active = -1          // 0-7 handle/edge, 8 pedal, 9 body, 10 white row, 11 black row
    private var lx = 0f
    private var ly = 0f
    private var pinch = false
    private var pdx = 0f; private var pdy = 0f; private var pmx = 0f; private var pmy = 0f
    private var testing = false

    private fun dp(v: Int) = (v * d).toInt()

    private fun button(t: String, f: () -> Unit) = Button(ctx).apply {
        text = t; textSize = 12f; isAllCaps = false; minWidth = 0; minimumWidth = 0
        setPadding(dp(12), 0, dp(12), 0); setOnClickListener { f() }
    }

    fun start(skipCard: Boolean = false) {
        if (running != null) return
        if (!Settings.canDrawOverlays(ctx)) { Engine.toast("Allow display over other apps first"); return }
        running = this
        if (skipCard) showEditor() else showCard()
    }

    private fun showCard() {
        val tv = TextView(ctx).apply {
            text = "Open the Roblox piano in the orientation you'll play in, then press Begin."
            setTextColor(Color.WHITE); setPadding(dp(8), dp(8), dp(8), dp(4))
        }
        val c = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xEE222222.toInt())
            addView(tv)
            addView(LinearLayout(ctx).apply {
                addView(button("Begin") { removeCard(); showEditor() })
                addView(button("Cancel") { close() })
            })
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(40) }
        wm.addView(c, lp); card = c
    }

    private fun removeCard() { card?.let { try { wm.removeView(it) } catch (e: Exception) {} }; card = null }

    private fun close() {
        removeCard()
        root?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        root = null
        running = null
    }

    private fun defaultLayout(): Layout {
        val m = ctx.resources.displayMetrics
        return Layout(m.widthPixels * 0.05f, m.heightPixels * 0.5f, m.widthPixels * 0.95f, m.heightPixels * 0.92f, null)
    }

    private fun showEditor() {
        layout = Engine.layout() ?: defaultLayout()
        ghost = GhostPianoView(ctx).apply { this.layout = this@PianoOverlay.layout; editable = true }

        val hint = TextView(ctx).apply {
            text = "1 finger: move  •  2 fingers: stretch  •  pull edges / yellow dots  •  drag the W and B dot rows onto the keys"
            setTextColor(Color.WHITE); textSize = 13f; setPadding(dp(10), dp(6), dp(10), dp(2))
        }
        pedalBtn = button("") { togglePedal() }
        val row = LinearLayout(ctx).apply {
            addView(button("Done") { save() })
            addView(button("Test") { testKeys() })
            addView(pedalBtn)
            addView(button("Cancel") { close() })
        }
        updatePedalLabel()
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xCC000000.toInt())
            addView(hint); addView(row)
        }
        val frame = FrameLayout(ctx).apply {
            setBackgroundColor(0x11000000)
            addView(ghost, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(bar, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL))
            setOnTouchListener { _, e -> onTouch(e); true }
        }
        wm.addView(frame, Overlay.full(0)); root = frame
    }

    private fun updatePedalLabel() { pedalBtn.text = if (layout.pedal == null) "Add pedal" else "Remove pedal" }

    private fun togglePedal() {
        layout.pedal = if (layout.pedal == null) PointF(layout.r - dp(40), layout.t - dp(30)) else null
        updatePedalLabel(); ghost.invalidate()
    }

    /** Where this overlay window really sits on the screen (touches are injected in screen coordinates). */
    private fun captureOffset() {
        val loc = IntArray(2)
        root?.getLocationOnScreen(loc)
        layout.ox = loc[0].toFloat(); layout.oy = loc[1].toFloat()
    }

    private fun setTouchable(on: Boolean) {
        val v = root ?: return
        val lp = v.layoutParams as? WindowManager.LayoutParams ?: return
        lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) {}
    }

    private fun testKeys() {
        if (testing) return
        val svc = TouchAccessibilityService.instance
        if (svc == null) { Engine.toast("Turn on the Auto Piano accessibility service first"); return }
        captureOffset()
        val s = Engine.settings()
        val inj = svc.injector
        inj.cal = Engine.calibrationFor(layout)
        testing = true
        setTouchable(false)          // let the injected touches reach the piano underneath
        val seq = ArrayList<Int>().apply { add(s.low); for (p in 60..72) add(p); add(s.high) }
        var t = 400L
        for (p in seq) {
            val k = p.coerceIn(s.low, s.high)
            Engine.main.postDelayed({ ghost.highlight = k; ghost.invalidate(); inj.down(k, 0) }, t)
            Engine.main.postDelayed({ inj.up(k, 0) }, t + 250)
            t += 450
        }
        Engine.main.postDelayed({ ghost.highlight = -1; ghost.invalidate(); setTouchable(true); testing = false }, t + 200)
    }

    private fun hit(x: Float, y: Float): Int {
        val L = layout
        val r = 30 * d
        Handles.points(L).forEachIndexed { i, p -> if (hypot(x - p.x, y - p.y) < r) return i }
        L.pedal?.let { if (hypot(x - it.x, y - it.y) < r) return 8 }
        val e = 24 * d
        val inV = y >= L.t - e && y <= L.b + e
        val inH = x >= L.l - e && x <= L.r + e
        if (inV && abs(x - L.l) < e) return 4
        if (inV && abs(x - L.r) < e) return 5
        if (inH && abs(y - L.t) < e) return 6
        if (inH && abs(y - L.b) < e) return 7
        if (x in L.l..L.r && y in L.t..L.b) {
            val h = L.b - L.t
            val dw = abs(y - (L.t + L.fw * h)); val db = abs(y - (L.t + L.fb * h))
            if (min(dw, db) < 24 * d) return if (dw <= db) 10 else 11
            return 9
        }
        return -1
    }

    private fun onTouch(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { pinch = false; active = hit(e.getX(0), e.getY(0)); lx = e.getX(0); ly = e.getY(0) }
            MotionEvent.ACTION_POINTER_DOWN -> if (e.pointerCount == 2) {
                pinch = true; active = -1
                pdx = abs(e.getX(0) - e.getX(1)); pdy = abs(e.getY(0) - e.getY(1))
                pmx = (e.getX(0) + e.getX(1)) / 2; pmy = (e.getY(0) + e.getY(1)) / 2
            }
            MotionEvent.ACTION_MOVE -> {
                if (pinch && e.pointerCount >= 2) pinchMove(e)
                else if (!pinch && active >= 0) {
                    val x = e.getX(0); val y = e.getY(0)
                    applyDrag(x - lx, y - ly); lx = x; ly = y; ghost.invalidate()
                }
            }
            MotionEvent.ACTION_POINTER_UP -> if (pinch && e.pointerCount <= 2) { pinch = false; active = -1 }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { active = -1; pinch = false }
        }
    }

    private fun pinchMove(e: MotionEvent) {
        val L = layout
        val ndx = abs(e.getX(0) - e.getX(1)); val ndy = abs(e.getY(0) - e.getY(1))
        val mx = (e.getX(0) + e.getX(1)) / 2; val my = (e.getY(0) + e.getY(1)) / 2
        val sx = if (pdx > 40 * d && ndx > 40 * d) ndx / pdx else 1f
        val sy = if (pdy > 40 * d && ndy > 40 * d) ndy / pdy else 1f
        L.l = mx + (L.l - pmx) * sx; L.r = mx + (L.r - pmx) * sx
        L.t = my + (L.t - pmy) * sy; L.b = my + (L.b - pmy) * sy
        L.pedal?.let { it.x += mx - pmx; it.y += my - pmy }
        if (L.r - L.l < 120 * d) L.r = L.l + 120 * d
        if (L.b - L.t < 40 * d) L.b = L.t + 40 * d
        pdx = ndx; pdy = ndy; pmx = mx; pmy = my
        ghost.invalidate()
    }

    private fun applyDrag(dx: Float, dy: Float) {
        val L = layout
        val minW = 120 * d; val minH = 40 * d
        val h = L.b - L.t
        when (active) {
            in 0..7 -> {
                val f = Handles.flags[active]
                if (f[0]) L.l += dx
                if (f[2]) L.r += dx
                if (f[1]) L.t += dy
                if (f[3]) L.b += dy
                if (L.r - L.l < minW) { if (f[0]) L.l = L.r - minW else L.r = L.l + minW }
                if (L.b - L.t < minH) { if (f[1]) L.t = L.b - minH else L.b = L.t + minH }
            }
            8 -> L.pedal?.let { it.x += dx; it.y += dy }
            9 -> { L.l += dx; L.r += dx; L.t += dy; L.b += dy }
            10 -> L.fw = (L.fw + dy / h).coerceIn(L.fb + 0.1f, 0.98f)
            11 -> L.fb = (L.fb + dy / h).coerceIn(0.04f, L.fw - 0.1f)
        }
    }

    private fun save() {
        captureOffset()
        Engine.saveLayout(layout)
        Engine.toast("Piano overlay saved (${Engine.orientationName()})")
        close()
    }
}
