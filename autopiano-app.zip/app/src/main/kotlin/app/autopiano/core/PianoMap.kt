package app.autopiano.core

data class KeyStroke(val key: Char, val shift: Boolean)

/**
 * Standard Virtual Piano 61-key layout: C2 (MIDI 36) .. C7 (MIDI 96).
 * Naturals run 1234567890qwertyuiopasdfghjklzxcvbnm; a sharp is Shift + the natural below it.
 * Notes outside the range are folded by octave in Scheduler (Settings.low/high).
 */
object PianoMap {
    const val LOW = 36
    private const val NATURALS = "1234567890qwertyuiopasdfghjklzxcvbnm"
    private val naturalSemis = intArrayOf(0, 2, 4, 5, 7, 9, 11)

    fun stroke(pitch: Int): KeyStroke {
        val rel = Scheduler.fold(pitch, 36, 96) - LOW
        val oct = rel / 12; val semi = rel % 12
        val i = naturalSemis.indexOf(semi)
        return if (i >= 0) KeyStroke(NATURALS[oct * 7 + i], false)
        else KeyStroke(NATURALS[oct * 7 + naturalSemis.indexOf(semi - 1)], true)
    }

    /** Android KeyEvent code for a piano key char: KEYCODE_0..9 = 7..16, KEYCODE_A..Z = 29..54. */
    fun androidKeyCode(c: Char): Int = if (c in '0'..'9') 7 + (c - '0') else 29 + (c - 'a')
}
