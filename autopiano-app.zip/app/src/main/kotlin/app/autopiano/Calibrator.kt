package app.autopiano

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PointF
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Overlay calibration with live feedback. Tap: 1 lowest white key, 2 highest white key, 3 any black key,
 * 4 pedal (or Skip). Each tap drops a numbered marker and the key dots preview updates immediately.
 * Afterwards you review: Save, or Redo just one point (the other points are kept).
 * Opening it again starts in review with your saved points, so you can fix a single one.
 */
class Calibrator(private val ctx: Context) {
    companion object { private var running: Calibrator? = null }

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = ctx.resources.displayMetrics.density
    private var card: View? = null
    private var capture: View? = null
    private lateinit var dots: KeyDotsView
    private lateinit var prompt: TextView
    private lateinit var buttons: LinearLayout

    private val pts = arrayOfNulls<PointF>(4)
    private var step = 0
    private var reviewing = false
    private var single = false          // redoing one point only
    private val names = listOf("LOWEST white key (far left)", "HIGHEST white key (far right)", "any BLACK key", "PEDAL button")
    private val tags = listOf("1 LOW", "2 HIGH", "3 BLACK", "4 PEDAL")

    private fun dp(v: Int) = (v * d).toInt()

    private fun params(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun button(t: String, f: () -> Unit) = Button(ctx).apply {
        text = t; textSize = 12f; isAllCaps = false; minWidth = 0; minimumWidth = 0
        setPadding(dp(10), 0, dp(10), 0); setOnClickListener { f() }
    }

    fun start(skipCard: Boolean = false) {
        if (running != null) return
        if (!Settings.canDrawOverlays(ctx)) { Engine.toast("Allow display over other apps first"); return }
        running = this
        if (skipCard) showCapture() else showCard()
    }

    private fun showCard() {
        val tv = TextView(ctx).apply {
            text = "Open the Roblox piano in the orientation you'll play in, then press Begin."
            setTextColor(Color.WHITE); setPadding(dp(8), dp(8), dp(8), dp(4))
        }
        val c = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xEE222222.toInt())
            addView(tv)
            addView(LinearLayout(ctx).apply {
                addView(button("Begin") { removeCard(); showCapture() })
                addView(button("Cancel") { close() })
            })
        }
        val lp = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL)
        lp.x = dp(8); lp.y = dp(40)
        wm.addView(c, lp); card = c
    }

    private fun removeCard() { card?.let { try { wm.removeView(it) } catch (e: Exception) {} }; card = null }

    private fun close() {
        removeCard()
        capture?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        capture = null
        running = null
    }

    private fun showCapture() {
        val saved = Engine.calibrationPoints()
        for (i in 0..3) pts[i] = saved[i]
        reviewing = pts[0] != null && pts[1] != null && pts[2] != null
        step = 0; single = false

        dots = KeyDotsView(ctx, showEnds = false)
        prompt = TextView(ctx).apply {
            setTextColor(Color.WHITE); textSize = 15f; setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        buttons = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xCC000000.toInt())
            addView(prompt); addView(buttons)
        }
        val root = FrameLayout(ctx).apply {
            setBackgroundColor(0x22000000)
            addView(dots, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            addView(bar, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.CENTER_HORIZONTAL))
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_UP) onTap(e.rawX, e.rawY)
                true
            }
        }
        val lp = params(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        wm.addView(root, lp); capture = root
        refresh()
    }

    private fun onTap(x: Float, y: Float) {
        if (reviewing) return
        pts[step] = PointF(x, y)
        if (single) { single = false; reviewing = true }
        else { step++; if (step >= 4) reviewing = true }
        refresh()
    }

    private fun preview(): Calibration? {
        val a = pts[0]; val b = pts[1]
        if (a == null || b == null || b.x <= a.x) return null
        val s = Engine.settings()
        val wy = (a.y + b.y) / 2
        val by = pts[2]?.y ?: (wy - 60 * d)       // guess until the black key is tapped
        val p = pts[3]
        return Calibration(s.low, s.high, a.x, b.x, wy, by, p?.x ?: -1f, p?.y ?: -1f)
    }

    private fun refresh() {
        dots.cal = preview()
        dots.markers = (0..3).mapNotNull { i -> pts[i]?.let { Triple(tags[i], it.x, it.y) } }
        dots.invalidate()

        buttons.removeAllViews()
        if (reviewing) {
            prompt.text = "Check the dots. Save, or redo one point."
            buttons.addView(button("Save") { save() })
            for (i in 0..3) buttons.addView(button("Redo ${i + 1}") { single = true; step = i; reviewing = false; refresh() })
        } else {
            prompt.text = (if (single) "Redo: " else "${step + 1}/4  ") + "Tap the ${names[step]}"
            if (single) buttons.addView(button("Keep old") { single = false; reviewing = true; refresh() })
            else if (step > 0) buttons.addView(button("Back") { step--; pts[step] = null; refresh() })
            if (step == 3) buttons.addView(button("Skip pedal") { pts[3] = null; single = false; reviewing = true; refresh() })
        }
        buttons.addView(button("Cancel") { close() })
    }

    private fun save() {
        val a = pts[0]; val b = pts[1]
        if (a == null || b == null || pts[2] == null || b.x <= a.x) {
            Engine.toast("Point 2 (highest key) must be to the right of point 1, and point 3 is needed. Redo a point.")
            return
        }
        Engine.saveCalibration(pts)
        Engine.toast("Touch calibration saved")
        close()
    }
}
