package app.autopiano

import android.graphics.PointF

/**
 * Touch layout from 4 taps: lowest white key, highest white key, any black key, pedal.
 * White keys are assumed evenly spaced; a black key sits halfway between its neighbours.
 */
class Calibration(
    val low: Int, val high: Int,
    private val leftX: Float, private val rightX: Float,
    private val whiteY: Float, private val blackY: Float,
    private val pedalX: Float, private val pedalY: Float
) {
    private val blackSemis = setOf(1, 3, 6, 8, 10)
    private fun isBlack(p: Int) = (p % 12) in blackSemis
    fun isBlackKey(p: Int) = isBlack(p)
    private val whiteCount = (low..high).count { !isBlack(it) }
    private val step = if (whiteCount > 1) (rightX - leftX) / (whiteCount - 1) else 0f
    private fun whiteIndex(p: Int) = (low until p).count { !isBlack(it) }

    fun point(p: Int): PointF? {
        if (p < low || p > high) return null
        val idx = whiteIndex(p)
        return if (isBlack(p)) PointF(leftX + (idx - 0.5f) * step, blackY)
        else PointF(leftX + idx * step, whiteY)
    }

    fun pedal(): PointF? = if (pedalX >= 0) PointF(pedalX, pedalY) else null
}

/**
 * The ghost piano rectangle you drag over the real keys (screen pixels), plus an optional pedal point.
 * White keys are evenly spaced across it; black keys sit on the white-key boundaries.
 * Touch points: white keys at 80% of the height, black keys at 30% (inside the drawn black key).
 */
class Layout(var l: Float, var t: Float, var r: Float, var b: Float, var pedal: PointF?) {
    fun toCalibration(low: Int, high: Int): Calibration {
        val black = setOf(1, 3, 6, 8, 10)
        val whites = (low..high).count { (it % 12) !in black }
        val ww = (r - l) / whites
        val h = b - t
        return Calibration(low, high, l + ww / 2, r - ww / 2, t + 0.8f * h, t + 0.3f * h,
            pedal?.x ?: -1f, pedal?.y ?: -1f)
    }
}
