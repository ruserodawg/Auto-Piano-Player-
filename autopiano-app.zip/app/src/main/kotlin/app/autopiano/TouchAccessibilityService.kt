package app.autopiano

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class TouchAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: TouchAccessibilityService? = null }

    val injector: TouchInjector by lazy { TouchInjector(this) }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}

/**
 * Holds keys with chained touch strokes. Android needs a stroke's length up front, so each key is a
 * series of short (SEG ms) continued strokes that end when the key is released. Consequence: a
 * press or release can be delayed by up to one segment (~30 ms). Max ~10 simultaneous touches.
 */
class TouchInjector(private val svc: AccessibilityService) {
    companion object { const val PEDAL = -1 }

    @Volatile var cal: Calibration? = null
    private val main = Handler(Looper.getMainLooper())
    private val lock = Any()
    private val active = HashMap<Int, GestureDescription.StrokeDescription>()
    private val toStart = LinkedHashSet<Int>()
    private val toEnd = HashSet<Int>()
    private var busy = false
    private val seg = 30L
    private val maxStrokes = GestureDescription.getMaxStrokeCount()

    fun down(key: Int) { synchronized(lock) { toStart.add(key) }; main.post { pump() } }
    fun up(key: Int) { synchronized(lock) { if (!toStart.remove(key)) toEnd.add(key) }; main.post { pump() } }
    fun pedal(down: Boolean) { if (down) down(PEDAL) else up(PEDAL) }

    private fun path(k: Int, c: Calibration): Path? {
        val p = (if (k == PEDAL) c.pedal() else c.point(k)) ?: return null
        return Path().apply { moveTo(p.x, p.y) }
    }

    private fun pump() {
        val c = cal
        val strokes = ArrayList<GestureDescription.StrokeDescription>()
        val next = HashMap<Int, GestureDescription.StrokeDescription>()
        synchronized(lock) {
            if (busy) return
            if (c == null) { active.clear(); toStart.clear(); toEnd.clear(); return }
            val ending = HashSet<Int>(toEnd); toEnd.clear()
            for ((k, sd) in active) {
                val p = path(k, c) ?: continue
                if (k in ending) strokes.add(sd.continueStroke(p, 0, seg, false))
                else { val n = sd.continueStroke(p, 0, seg, true); strokes.add(n); next[k] = n }
            }
            val iter = toStart.iterator()
            while (iter.hasNext()) {
                val k = iter.next()
                if (k in ending) continue                 // re-strike: release this round, press next round
                if (strokes.size >= maxStrokes) break
                if (k in next) { iter.remove(); continue }
                val p = path(k, c)
                iter.remove()
                if (p != null) {
                    val n = GestureDescription.StrokeDescription(p, 0, seg, true)
                    strokes.add(n); next[k] = n
                }
            }
            if (strokes.isEmpty()) { active.clear(); return }
            busy = true
        }
        val b = GestureDescription.Builder()
        strokes.forEach { b.addStroke(it) }
        val ok = svc.dispatchGesture(b.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { done(next, true) }
            override fun onCancelled(g: GestureDescription?) { done(next, false) }
        }, main)
        if (!ok) synchronized(lock) { busy = false; active.clear() }
    }

    private fun done(next: Map<Int, GestureDescription.StrokeDescription>, completed: Boolean) {
        synchronized(lock) {
            active.clear()
            if (completed) active.putAll(next)
            busy = false
        }
        pump()
    }
}
