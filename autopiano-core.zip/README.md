# autopiano-core

Pure-Kotlin core for a MIDI auto-piano player: MIDI parsing, scheduling (humanization, tempo jitter),
and a playback engine with live tempo, pause/seek and stuck-key protection.

Run tests locally: `gradle test` (JDK 17). CI: `.github/workflows/build.yml`.

Next stages: Bluetooth-keyboard sink, Accessibility touch sink, Android service/overlay/UI.
