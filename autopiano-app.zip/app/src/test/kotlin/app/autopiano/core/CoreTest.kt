package app.autopiano.core

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertTrue

class CoreTest {

    // ---- helpers ----------------------------------------------------------

    private fun vlq(v: Int): List<Int> {
        var x = v
        val out = arrayListOf(x and 0x7F)
        x = x shr 7
        while (x > 0) { out.add(0, (x and 0x7F) or 0x80); x = x shr 7 }
        return out
    }

    private fun ev(delta: Int, vararg b: Int): List<Int> = vlq(delta) + b.toList()

    private fun smf(ppq: Int, events: List<List<Int>>): ByteArray {
        val track = events.flatten() + ev(0, 0xFF, 0x2F, 0x00)
        val out = ArrayList<Int>()
        fun s(t: String) = t.forEach { out.add(it.code) }
        fun i32(v: Int) { out.add(v ushr 24 and 0xFF); out.add(v ushr 16 and 0xFF); out.add(v ushr 8 and 0xFF); out.add(v and 0xFF) }
        fun i16(v: Int) { out.add(v ushr 8 and 0xFF); out.add(v and 0xFF) }
        s("MThd"); i32(6); i16(0); i16(1); i16(ppq)
        s("MTrk"); i32(track.size); out.addAll(track)
        return ByteArray(out.size) { out[it].toByte() }
    }

    private class Rec : KeySink {
        val log = ArrayList<String>()
        val down = HashSet<Int>()
        var pedalOn = false
        override fun down(pitch: Int) { log.add("d$pitch"); down.add(pitch) }
        override fun up(pitch: Int) { log.add("u$pitch"); down.remove(pitch) }
        override fun pedal(down: Boolean) { log.add(if (down) "P+" else "P-"); pedalOn = down }
    }

    private fun song(vararg n: Triple<Double, Double, Int>, pedal: List<PedalEvent> = emptyList()) =
        Song(n.map { Note(it.first, it.second, it.third, 0) }, pedal)

    // ---- parser -----------------------------------------------------------

    @Test fun parserAppliesTempoChanges() {
        val data = smf(480, listOf(
            ev(0, 0xFF, 0x51, 0x03, 0x07, 0xA1, 0x20),   // 500000 us/quarter
            ev(0, 0x90, 60, 64), ev(480, 0x80, 60, 0),   // 0..500 ms
            ev(0, 0xFF, 0x51, 0x03, 0x03, 0xD0, 0x90),   // 250000 us/quarter
            ev(0, 0x90, 62, 64), ev(480, 0x80, 62, 0)    // 500..750 ms
        ))
        val s = MidiParser.parse(data)
        assertEquals(2, s.notes.size)
        assertEquals(500.0, s.notes[0].endMs, 0.01)
        assertEquals(500.0, s.notes[1].startMs, 0.01)
        assertEquals(750.0, s.notes[1].endMs, 0.01)
    }

    @Test fun parserHandlesRunningStatusAndNoteOnVelocityZero() {
        val data = smf(480, listOf(
            ev(0, 0x90, 60, 64), ev(0, 64, 64),           // running status: 2nd note-on
            ev(480, 60, 0), ev(0, 64, 0)                  // note-on vel 0 = off
        ))
        val s = MidiParser.parse(data)
        assertEquals(2, s.notes.size)
        assertEquals(500.0, s.notes[0].endMs, 0.01)
        assertEquals(500.0, s.notes[1].endMs, 0.01)
    }

    @Test fun parserReadsPedal() {
        val data = smf(480, listOf(
            ev(0, 0xB0, 64, 127), ev(0, 0x90, 60, 64),
            ev(480, 0x80, 60, 0), ev(0, 0xB0, 64, 0)
        ))
        val s = MidiParser.parse(data)
        assertEquals(2, s.pedal.size)
        assertTrue(s.pedal[0].down); assertFalse(s.pedal[1].down)
    }

    // ---- scheduler --------------------------------------------------------

    @Test fun samePitchOverlapIsReleasedBeforeRestrike() {
        val sch = Scheduler.build(song(Triple(0.0, 1000.0, 60), Triple(500.0, 1500.0, 60)), Settings())
        val a = sch.actions.filter { it.pitch == 60 }.map { it.kind to it.timeMs }
        // DOWN 0, UP before 500, DOWN 500, UP 1500
        assertEquals(Kind.DOWN, a[0].first)
        assertEquals(Kind.UP, a[1].first); assertTrue(a[1].second < 500.0)
        assertEquals(Kind.DOWN, a[2].first)
    }

    @Test fun humanizeKeepsPairsDurationsAndOrder() {
        val notes = (0 until 50).map { Triple(it * 200.0, it * 200.0 + 150.0, 60 + it % 12) }
        val st = Settings(humanize = true, humanIntensity = 1.0, tempoJitter = true, jitterIntensity = 1.0)
        val sch = Scheduler.build(song(*notes.toTypedArray()), st)
        assertEquals(100, sch.actions.size)
        // every DOWN has a later UP, and no key is down twice
        val down = HashSet<Int>()
        for (a in sch.actions) when (a.kind) {
            Kind.DOWN -> assertTrue(down.add(a.pitch))
            Kind.UP -> assertTrue(down.remove(a.pitch))
            else -> {}
        }
        assertTrue(down.isEmpty())
        // no drift: last note stays near its original start (bounded by ~25ms + 40ms)
        val lastDown = sch.actions.last { it.kind == Kind.DOWN }
        assertTrue(kotlin.math.abs(lastDown.timeMs - 49 * 200.0) < 80.0)
    }

    @Test fun chordStaysTight() {
        val st = Settings(humanize = true, humanIntensity = 1.0)
        val sch = Scheduler.build(song(Triple(1000.0, 2000.0, 60), Triple(1000.0, 2000.0, 64), Triple(1000.0, 2000.0, 67)), st)
        val ons = sch.actions.filter { it.kind == Kind.DOWN }.map { it.timeMs }
        assertTrue(ons.max() - ons.min() <= 8.0 + 1e-9)
    }

    @Test fun arpeggioStaggersChordLowToHigh() {
        val sch = Scheduler.build(
            song(Triple(1000.0, 2000.0, 67), Triple(1000.0, 2000.0, 60), Triple(1000.0, 2000.0, 64)),
            Settings(arpMs = 10.0)
        )
        val ons = sch.actions.filter { it.kind == Kind.DOWN }
        assertEquals(listOf(60, 64, 67), ons.map { it.pitch })
        assertEquals(1000.0, ons[0].timeMs, 0.01)
        assertEquals(1010.0, ons[1].timeMs, 0.01)
        assertEquals(1020.0, ons[2].timeMs, 0.01)
    }

    @Test fun voiceCapNeverExceeded() {
        val notes = (0 until 14).map { Triple(1000.0, 3000.0, 48 + it) }
        val sch = Scheduler.build(song(*notes.toTypedArray()), Settings(arpMs = 10.0, maxVoices = 9))
        var cur = 0; var peak = 0
        for (a in sch.actions) when (a.kind) {
            Kind.DOWN -> { cur++; peak = maxOf(peak, cur) }
            Kind.UP -> cur--
            else -> {}
        }
        assertTrue(peak <= 9)
        assertEquals(14, sch.actions.count { it.kind == Kind.DOWN })   // nothing dropped, only shortened
        assertEquals(0, cur)
    }

    @Test fun chordNotesAreSentTogetherWithExactDelays() {
        val sink = object : KeySink {
            val delays = ArrayList<Pair<Int, Long>>()
            override fun down(pitch: Int) {}
            override fun up(pitch: Int) {}
            override fun pedal(down: Boolean) {}
            override fun downIn(pitch: Int, delayMs: Long) { delays.add(pitch to delayMs) }
        }
        val p = Player(sink, useThread = false, clock = { 0L })
        p.load(song(Triple(1000.0, 2000.0, 60), Triple(1010.0, 2000.0, 64), Triple(1020.0, 2000.0, 67)))
        p.play(); p.advanceTo(990.0)
        assertEquals(listOf(60 to 10L, 64 to 20L, 67 to 30L), sink.delays)
    }

    @Test fun pianoMapStandardKeys() {
        assertEquals(KeyStroke('1', false), PianoMap.stroke(36))
        assertEquals(KeyStroke('1', true), PianoMap.stroke(37))
        assertEquals(KeyStroke('t', false), PianoMap.stroke(60))
        assertEquals(KeyStroke('m', false), PianoMap.stroke(96))
        assertEquals(KeyStroke('t', false), PianoMap.stroke(24 + 36))
    }

    // ---- player -----------------------------------------------------------

    private class Fixture {
        var now = 0L
        val rec = Rec()
        val p = Player(rec, useThread = false, clock = { now })
        fun ms(v: Long) { now += v * 1_000_000 }
    }

    @Test fun pauseReleasesEverythingAndResumeDoesNotDoubleRelease() {
        val f = Fixture()
        f.p.load(song(Triple(0.0, 1000.0, 60), Triple(500.0, 1500.0, 64)))
        f.p.play(); f.p.advanceTo(600.0)
        assertEquals(setOf(60, 64), f.rec.down)
        f.p.pause()
        assertTrue(f.rec.down.isEmpty())
        assertEquals(PlayState.PAUSED, f.p.playState())
        f.p.play(); f.p.advanceTo(2000.0)
        assertEquals(1, f.rec.log.count { it == "u60" })   // only the pause release
        assertTrue(f.rec.down.isEmpty())
    }

    @Test fun stopReleasesAllAndPedal() {
        val f = Fixture()
        f.p.load(song(Triple(0.0, 1000.0, 60)))
        f.p.setManualPedal(true)
        f.p.configure(Settings(followMidiPedal = false))
        f.p.play(); f.p.advanceTo(100.0)
        assertTrue(f.rec.pedalOn)
        f.p.stop()
        assertTrue(f.rec.down.isEmpty()); assertFalse(f.rec.pedalOn)
        assertEquals(0.0, f.p.positionMs(), 0.0)
    }

    @Test fun liveTempoChangeAffectsPositionImmediately() {
        val f = Fixture()
        f.p.load(song(Triple(0.0, 10000.0, 60)))
        f.p.play()
        f.ms(1000)
        assertEquals(1000.0, f.p.positionMs(), 0.01)
        f.p.setTempo(2.0)
        f.ms(1000)
        assertEquals(3000.0, f.p.positionMs(), 0.01)   // 1000 + 1000 * 2
        f.p.setTempo(0.5)
        f.ms(1000)
        assertEquals(3500.0, f.p.positionMs(), 0.01)
    }

    @Test fun seekReleasesNotesAndSkipsEarlierEvents() {
        val f = Fixture()
        f.p.load(song(Triple(0.0, 1000.0, 60), Triple(2000.0, 3000.0, 62)))
        f.p.play(); f.p.advanceTo(100.0)
        f.p.seek(1500.0)
        assertTrue(f.rec.down.isEmpty())
        f.p.advanceTo(2100.0)
        assertEquals(setOf(62), f.rec.down)
    }

    @Test fun midiPedalControlsPedalWhenPresentAndManualIsIgnored() {
        val f = Fixture()
        f.p.load(song(Triple(0.0, 1000.0, 60), pedal = listOf(PedalEvent(100.0, true), PedalEvent(800.0, false))))
        f.p.setManualPedal(true)
        f.p.play(); f.p.advanceTo(50.0)
        assertFalse(f.rec.pedalOn)           // MIDI pedal not down yet, manual ignored
        f.p.advanceTo(200.0); assertTrue(f.rec.pedalOn)
        f.p.advanceTo(900.0); assertFalse(f.rec.pedalOn)
    }

    @Test fun sinkErrorStopsAndReleases() {
        var fail = false
        val rec = Rec()
        val sink = object : KeySink {
            override fun down(pitch: Int) { if (fail) throw RuntimeException("boom"); rec.down(pitch) }
            override fun up(pitch: Int) = rec.up(pitch)
            override fun pedal(down: Boolean) = rec.pedal(down)
        }
        val p = Player(sink, useThread = false)
        var err: Throwable? = null
        p.onError = { err = it }
        p.load(song(Triple(0.0, 500.0, 60), Triple(100.0, 500.0, 62)))
        p.play(); p.advanceTo(10.0)
        fail = true
        p.advanceTo(200.0)
        assertTrue(err != null)
        assertEquals(PlayState.STOPPED, p.playState())
        assertTrue(rec.down.isEmpty())
    }
}
