plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.me.autopiano"
    compileSdk = 34
    defaultConfig { applicationId = "com.me.autopiano"; minSdk = 28; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1") }
