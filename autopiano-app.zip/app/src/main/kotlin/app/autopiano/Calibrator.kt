package app.autopiano

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PointF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Overlay calibration: open the piano in Roblox first (same orientation you will play in), press Begin,
 * then tap: lowest white key, highest white key, any black key, pedal (or Skip).
 */
class Calibrator(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var card: View? = null
    private var capture: View? = null
    private val pts = ArrayList<PointF>()
    private val prompts = listOf(
        "1/4  Tap the LOWEST white key (far left)",
        "2/4  Tap the HIGHEST white key (far right)",
        "3/4  Tap any BLACK key",
        "4/4  Tap the PEDAL button (or press Skip)"
    )

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun params(w: Int, h: Int, flags: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun button(t: String, f: () -> Unit) = Button(ctx).apply {
        text = t; isAllCaps = false; setOnClickListener { f() }
    }

    fun start() {
        val tv = TextView(ctx).apply {
            text = "Open the Roblox piano, then press Begin."; setTextColor(Color.WHITE); setPadding(dp(8), dp(8), dp(8), dp(4))
        }
        val c = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xEE222222.toInt())
            addView(tv)
            addView(LinearLayout(ctx).apply {
                addView(button("Begin") { removeCard(); showCapture() })
                addView(button("Cancel") { removeCard() })
            })
        }
        val lp = params(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL)
        lp.x = dp(8); lp.y = dp(40)
        wm.addView(c, lp); card = c
    }

    private fun removeCard() { card?.let { try { wm.removeView(it) } catch (e: Exception) {} }; card = null }
    private fun removeCapture() { capture?.let { try { wm.removeView(it) } catch (e: Exception) {} }; capture = null }

    private fun showCapture() {
        pts.clear()
        val prompt = TextView(ctx).apply {
            text = prompts[0]; setTextColor(Color.WHITE); textSize = 16f
            setBackgroundColor(0xCC000000.toInt()); setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        val skip = button("Skip pedal") { finish() }.apply { visibility = View.GONE }
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(prompt); addView(skip); addView(button("Cancel") { removeCapture() })
        }
        val root = FrameLayout(ctx).apply {
            setBackgroundColor(0x22000000)
            addView(bar, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_UP) {
                    pts.add(PointF(e.rawX, e.rawY))
                    if (pts.size >= 4) finish()
                    else { prompt.text = prompts[pts.size]; skip.visibility = if (pts.size == 3) View.VISIBLE else View.GONE }
                }
                true
            }
        }
        val lp = params(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        wm.addView(root, lp); capture = root
    }

    private fun finish() {
        removeCapture()
        if (pts.size < 3 || pts[1].x <= pts[0].x) {
            Engine.toast("Calibration failed: tap lowest key first, then highest key (to its right). Try again."); return
        }
        val ped = pts.getOrNull(3)
        Engine.saveCalibration(pts[0].x, pts[1].x, (pts[0].y + pts[1].y) / 2, pts[2].y, ped?.x ?: -1f, ped?.y ?: -1f)
        Engine.toast("Touch calibration saved")
    }
}
