package app.autopiano

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class TouchAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: TouchAccessibilityService? = null }

    val injector: TouchInjector by lazy { TouchInjector(this) }

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}

/**
 * Holds keys with chained touch strokes (Android needs a stroke's length up front).
 *
 * - Press/release events go into an ordered queue and are never dropped; a note released before its press
 *   was sent still gets one short touch.
 * - Segment length is adaptive: the player tells us when the next event is due, so a held key is chained in
 *   long segments (up to MAX_SEG) and a segment ends just before the next event. That means few hand-overs
 *   between gestures while a note is held, and new notes start almost exactly on time.
 * - A watchdog frees the injector if Android never reports a gesture as finished.
 */
class TouchInjector(private val svc: AccessibilityService) {
    companion object { const val PEDAL = -1 }

    @Volatile var cal: Calibration? = null
    @Volatile var cancelled = 0
    @Volatile var failed = 0
    val maxStrokes: Int = GestureDescription.getMaxStrokeCount()

    private val main = Handler(Looper.getMainLooper())
    private val lock = Any()
    private val active = HashMap<Int, GestureDescription.StrokeDescription>()
    private val queue = ArrayDeque<Pair<Int, Boolean>>()      // (key, isDown) in arrival order
    private var busy = false
    private var busySince = 0L
    @Volatile private var nextEventNs = 0L
    private val minSeg = 20L
    private val maxSeg = 80L
    private val eventSeg = 35L        // gestures that start/stop a key last at least this long (reliable registration)

    fun nextEventIn(ms: Long) { nextEventNs = System.nanoTime() + ms * 1_000_000L }

    fun down(key: Int) { synchronized(lock) { queue.addLast(key to true) }; main.post { pump() } }
    fun up(key: Int) { synchronized(lock) { queue.addLast(key to false) }; main.post { pump() } }
    fun pedal(down: Boolean) { if (down) down(PEDAL) else up(PEDAL) }

    private fun path(k: Int, c: Calibration): Path? {
        val p = (if (k == PEDAL) c.pedal() else c.point(k)) ?: return null
        return Path().apply { moveTo(p.x, p.y) }
    }

    private fun pump() {
        val c = cal
        val strokes = LinkedHashMap<Int, GestureDescription.StrokeDescription>()
        val keep = HashSet<Int>()                 // keys still held after this gesture
        var seg = 0L
        synchronized(lock) {
            val now = System.nanoTime()
            if (busy) {
                if (now - busySince > 1_000_000_000L) { busy = false; active.clear() }   // watchdog
                else return
            }
            if (c == null) { active.clear(); queue.clear(); return }
            val untilNext = (nextEventNs - now) / 1_000_000L
            seg = (untilNext - 3).coerceIn(minSeg, maxSeg)
            if (queue.isNotEmpty()) seg = maxOf(seg, eventSeg)

            for ((k, sd) in active) {
                val p = path(k, c) ?: continue
                strokes[k] = sd.continueStroke(p, 0, seg, true); keep.add(k)
            }
            val started = HashSet<Int>()
            val ended = HashSet<Int>()
            while (queue.isNotEmpty()) {
                val (k, isDown) = queue.first()
                if (isDown) {
                    if (k in keep) { queue.removeFirst(); continue }                 // already held
                    if (k in ended || k in started || strokes.size >= maxStrokes) break   // wait for next gesture
                    queue.removeFirst()
                    val p = path(k, c)
                    if (p != null) { strokes[k] = GestureDescription.StrokeDescription(p, 0, seg, true); keep.add(k); started.add(k) }
                } else {
                    queue.removeFirst()
                    val p = path(k, c) ?: continue
                    if (k in started) {                       // pressed and released in one gesture: one short touch
                        strokes[k] = GestureDescription.StrokeDescription(p, 0, seg, false)
                        keep.remove(k); started.remove(k); ended.add(k)
                    } else if (k in keep) {                   // held from before: end it now
                        strokes[k] = active[k]!!.continueStroke(p, 0, seg, false)
                        keep.remove(k); ended.add(k)
                    }
                }
            }
            if (strokes.isEmpty()) { active.clear(); return }
            busy = true; busySince = now
        }
        val next = HashMap<Int, GestureDescription.StrokeDescription>()
        for (k in keep) strokes[k]?.let { next[k] = it }
        val b = GestureDescription.Builder()
        strokes.values.forEach { b.addStroke(it) }
        val ok = svc.dispatchGesture(b.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { done(next, true) }
            override fun onCancelled(g: GestureDescription?) { cancelled++; done(next, false) }
        }, main)
        if (!ok) { failed++; synchronized(lock) { busy = false; active.clear() } }
    }

    private fun done(next: Map<Int, GestureDescription.StrokeDescription>, completed: Boolean) {
        synchronized(lock) {
            active.clear()
            if (completed) active.putAll(next)
            busy = false
        }
        pump()
    }
}
