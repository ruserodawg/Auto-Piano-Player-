package com.me.autopiano

class Note(val t: Double, val key: Int, var dur: Double)
class Pedal(val t: Double, val dur: Double)
class Song(val notes: List<Note>, val pedals: List<Pedal>, val len: Double)

object Midi {
    private class Ev(val tick: Long, val key: Int, val on: Boolean)

    fun parse(b: ByteArray): Song {
        var p = 0
        fun u8() = b[p++].toInt() and 0xFF
        fun u16() = (u8() shl 8) or u8()
        fun u32() = (u16() shl 16) or u16()
        fun vlq(): Int { var v = 0; while (true) { val c = u8(); v = (v shl 7) or (c and 0x7F); if (c < 0x80) return v } }
        require(u32() == 0x4D546864) { "Not a MIDI file" }
        val hl = u32(); u16(); val ntr = u16(); var div = u16()
        if (div <= 0) div = 480
        p = 8 + hl
        val tempos = ArrayList<LongArray>(); val evs = ArrayList<Ev>(); val peds = ArrayList<Ev>()
        for (tr in 0 until ntr) {
            if (p + 8 > b.size) break
            u32(); val len = u32(); val end = minOf(p + len, b.size)
            var tick = 0L; var run = 0
            while (p < end) {
                tick += vlq()
                var s = u8()
                if (s < 0x80) { p--; s = run } else if (s < 0xF0) run = s
                if (s == 0xFF) {
                    val ty = u8(); val l = vlq()
                    if (ty == 0x51 && l == 3) tempos.add(longArrayOf(tick, ((u8() shl 16) or (u8() shl 8) or u8()).toLong())) else p += l
                } else if (s == 0xF0 || s == 0xF7) {
                    p += vlq()
                } else {
                    val hi = s and 0xF0; val a = u8(); val c = if (hi == 0xC0 || hi == 0xD0) 0 else u8()
                    if ((s and 0x0F) != 9) {
                        if (hi == 0x90) evs.add(Ev(tick, a, c > 0))
                        else if (hi == 0x80) evs.add(Ev(tick, a, false))
                        else if (hi == 0xB0 && a == 64) peds.add(Ev(tick, 0, c >= 64))
                    }
                }
            }
            p = end
        }
        tempos.sortBy { it[0] }
        if (tempos.isEmpty() || tempos[0][0] != 0L) tempos.add(0, longArrayOf(0, 500000))
        val tk = LongArray(tempos.size) { tempos[it][0] }
        val tu = LongArray(tempos.size) { tempos[it][1] }
        val tm = DoubleArray(tempos.size)
        for (i in 1 until tk.size) tm[i] = tm[i - 1] + (tk[i] - tk[i - 1]).toDouble() * tu[i - 1] / div / 1000.0
        fun ms(t: Long): Double {
            var i = java.util.Arrays.binarySearch(tk, t); if (i < 0) i = -i - 2
            return tm[i] + (t - tk[i]).toDouble() * tu[i] / div / 1000.0
        }
        evs.sortWith(compareBy<Ev>({ it.tick }, { it.on }))
        val open = HashMap<Int, Double>(); val notes = ArrayList<Note>(); var endMs = 0.0
        for (e in evs) {
            val t = ms(e.tick); endMs = maxOf(endMs, t)
            if (e.on) {
                val o = open[e.key]; if (o != null) notes.add(Note(o, e.key, maxOf(30.0, t - o)))
                open[e.key] = t
            } else {
                val o = open.remove(e.key); if (o != null) notes.add(Note(o, e.key, maxOf(30.0, t - o)))
            }
        }
        for ((k, s) in open) notes.add(Note(s, k, maxOf(30.0, endMs - s)))
        notes.sortBy { it.t }
        // never let a note run into the next onset of the same key (keeps re-strikes clean, full length otherwise)
        val lastIdx = HashMap<Int, Int>()
        for (i in notes.indices) {
            val nt = notes[i]; val pi = lastIdx[nt.key]
            if (pi != null) { val pr = notes[pi]; pr.dur = minOf(pr.dur, maxOf(40.0, nt.t - pr.t - 15)) }
            lastIdx[nt.key] = i
        }
        peds.sortBy { it.tick }
        val pl = ArrayList<Pedal>(); var ps = -1.0
        for (e in peds) {
            val t = ms(e.tick)
            if (e.on) { if (ps < 0) ps = t } else if (ps >= 0) { pl.add(Pedal(ps, t - ps)); ps = -1.0 }
        }
        if (ps >= 0) pl.add(Pedal(ps, maxOf(0.0, endMs - ps)))
        var len = endMs
        for (n in notes) len = maxOf(len, n.t + n.dur)
        return Song(notes, pl, len)
    }
}
