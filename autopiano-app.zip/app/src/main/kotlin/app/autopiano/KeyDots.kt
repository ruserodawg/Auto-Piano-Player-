package app.autopiano

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/** Click-through overlay that draws a dot where every key (and the pedal) will be touched. */
object KeyDots {
    private var view: View? = null
    private var wm: WindowManager? = null
    private val autoHide = Runnable { hide() }

    fun toggle(ctx: Context) { if (view != null) hide() else show(ctx, 0) }

    fun show(ctx: Context, autoHideMs: Long) {
        hide()
        val app = ctx.applicationContext
        val cal = Engine.calibration() ?: run { Engine.toast("Calibrate touch positions first"); return }
        if (!Settings.canDrawOverlays(app)) { Engine.toast("Allow display over other apps first"); return }
        val w = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val v = DotsView(app, cal)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        w.addView(v, lp)
        wm = w; view = v
        if (autoHideMs > 0) Engine.main.postDelayed(autoHide, autoHideMs)
    }

    fun hide() {
        Engine.main.removeCallbacks(autoHide)
        view?.let { try { wm?.removeView(it) } catch (e: Exception) {} }
        view = null
    }

    private class DotsView(ctx: Context, private val cal: Calibration) : View(ctx) {
        private val d = ctx.resources.displayMetrics.density
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.BLACK; strokeWidth = 1.5f * d }
        private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.YELLOW; strokeWidth = 3f * d }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 11f * d; textAlign = Paint.Align.CENTER
            setShadowLayer(3f * d, 0f, 0f, Color.BLACK)
        }

        private fun dot(x: Float, y: Float, color: Int, r: Float) {
            fill.color = color
            canvasRef?.drawCircle(x, y, r, fill); canvasRef?.drawCircle(x, y, r, stroke)
        }
        private var canvasRef: Canvas? = null

        override fun onDraw(c: Canvas) {
            canvasRef = c
            for (p in cal.low..cal.high) {
                val pt = cal.point(p) ?: continue
                val black = cal.isBlackKey(p)
                dot(pt.x, pt.y, if (black) 0xFFFF4081.toInt() else 0xFF00E5FF.toInt(), (if (black) 5f else 6f) * d)
                if (p % 12 == 0 && !black) c.drawText("C${p / 12 - 1}", pt.x, pt.y - 12 * d, text)
                if (p == cal.low || p == cal.high) {
                    c.drawCircle(pt.x, pt.y, 13 * d, ring)
                    c.drawText(if (p == cal.low) "LOW" else "HIGH", pt.x, pt.y + 28 * d, text)
                }
            }
            cal.pedal()?.let { dot(it.x, it.y, Color.YELLOW, 8 * d); c.drawText("PEDAL", it.x, it.y - 14 * d, text) }
            canvasRef = null
        }
    }
}
