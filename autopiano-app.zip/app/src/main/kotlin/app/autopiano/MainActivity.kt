package app.autopiano

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var listBox: LinearLayout
    private val ui: () -> Unit = { refreshList(); refreshStatus() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun head(t: String) = TextView(this).apply {
        text = t; textSize = 16f; setPadding(0, dp(16), 0, dp(4))
    }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { f() }
    }
    private fun check(t: String, key: String, def: Boolean) = CheckBox(this).apply {
        text = t; isChecked = Engine.getBool(key, def)
        setOnCheckedChangeListener { _, v -> Engine.setBool(key, v); Engine.applySettings() }
    }
    private fun slider(t: String, key: String, def: Int): View {
        val label = TextView(this)
        val bar = SeekBar(this).apply { max = 100; progress = Engine.getInt(key, def) }
        label.text = "$t: ${bar.progress}%"
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { label.text = "$t: $p%" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                Engine.setInt(key, bar.progress); Engine.applySettings()
            }
        })
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(label); addView(bar) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.init(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(24), dp(14), dp(24))
        }
        root.addView(TextView(this).apply { text = "Auto Piano"; textSize = 22f })

        status = TextView(this)
        root.addView(head("Setup"))
        root.addView(status)
        root.addView(btn("1. Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(btn("2. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })

        root.addView(head("Player"))
        root.addView(ControlPanel(this))

        root.addView(head("MIDI library"))
        root.addView(btn("Import MIDI files…") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }
            startActivityForResult(i, 10)
        })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)
        root.addView(TextView(this).apply { text = "Tap = select. Long-press = delete."; textSize = 12f })

        root.addView(head("Piano"))
        val rg = RadioGroup(this).apply { orientation = LinearLayout.HORIZONTAL }
        val r61 = RadioButton(this).apply { text = "61 keys"; id = 61 }
        val r88 = RadioButton(this).apply { text = "88 keys"; id = 88 }
        rg.addView(r61); rg.addView(r88)
        rg.check(if (Engine.is88()) 88 else 61)
        rg.setOnCheckedChangeListener { _, id -> Engine.setIs88(id == 88); refreshStatus() }
        root.addView(rg)
        root.addView(btn("Calibrate touch positions") {
            if (!Settings.canDrawOverlays(this)) { Engine.toast("Allow display over other apps first"); return@btn }
            PlayerService.ensure(this)
            Calibrator(applicationContext).start()
        })

        root.addView(head("Humanization"))
        root.addView(check("Humanize timing", "human", false))
        root.addView(slider("Humanize intensity", "hInt", 30))
        root.addView(check("Tempo jitter (slow, bounded wander)", "jitter", false))
        root.addView(slider("Jitter intensity", "jInt", 30))
        root.addView(head("Sustain pedal"))
        root.addView(check("Follow MIDI pedal events when the file has them", "follow", true))

        root.addView(head("Floating panel"))
        root.addView(btn("Show floating panel") {
            if (!Settings.canDrawOverlays(this)) Engine.toast("Allow display over other apps first")
            else PlayerService.show(this)
        })
        root.addView(btn("Hide panel and stop service") { PlayerService.quit(this) })

        root.addView(TextView(this).apply {
            textSize = 12f; setPadding(0, dp(16), 0, 0)
            text = "Touch mode presses keys through an accessibility service: it only works while the service " +
                "is on and calibrated, and a press/release can be up to ~30 ms late. Max ~10 notes at once. " +
                "Calibrate in the same screen orientation you play in."
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); Engine.listeners.add(ui); ui() }
    override fun onPause() { Engine.listeners.remove(ui); super.onPause() }

    private fun refreshStatus() {
        val a11y = if (TouchAccessibilityService.instance != null) "ON" else "OFF"
        val ov = if (Settings.canDrawOverlays(this)) "ON" else "OFF"
        val cal = if (Engine.calibration() != null) "done" else "missing"
        status.text = "Accessibility service: $a11y\nOverlay permission: $ov\n" +
            "Touch calibration (${if (Engine.is88()) 88 else 61}-key): $cal"
    }

    private fun refreshList() {
        listBox.removeAllViews()
        val files = Engine.files()
        if (files.isEmpty()) listBox.addView(TextView(this).apply { text = "No MIDI files yet. Import some." })
        for (f in files) {
            listBox.addView(TextView(this).apply {
                text = (if (f.name == Engine.currentName()) "▶ " else "    ") + f.name
                textSize = 15f; setPadding(dp(4), dp(10), dp(4), dp(10))
                setOnClickListener { Engine.select(f) }
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setMessage("Delete ${f.name}?")
                        .setPositiveButton("Delete") { _, _ -> Engine.delete(f) }
                        .setNegativeButton("Cancel", null).show()
                    true
                }
            })
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 10 || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.clipData?.let { cd -> for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) }
        data.data?.let { uris.add(it) }
        Thread { uris.forEach { Engine.importUri(it) } }.start()
    }
}
