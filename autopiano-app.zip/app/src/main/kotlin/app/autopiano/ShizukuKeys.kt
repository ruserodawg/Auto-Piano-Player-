package app.autopiano

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import rikka.shizuku.Shizuku

/** App-side handle to the key injector that runs inside Shizuku. */
object ShizukuKeys {
    private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
    private lateinit var app: Context
    @Volatile private var svc: IKeyInjector? = null
    @Volatile private var ready = false
    @Volatile private var svcError = ""
    private var listening = false

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val s = if (binder != null && binder.pingBinder()) IKeyInjector.Stub.asInterface(binder) else null
            svc = s
            try { ready = s?.ready() ?: false; svcError = s?.error() ?: "" } catch (e: Exception) { ready = false; svcError = e.toString() }
            Engine.notifyUi()
        }
        override fun onServiceDisconnected(name: ComponentName?) { svc = null; ready = false; Engine.notifyUi() }
    }

    fun init(c: Context) {
        app = c.applicationContext
        if (listening) return
        listening = true
        try {
            Shizuku.addBinderReceivedListenerSticky { connect(); Engine.notifyUi() }
            Shizuku.addBinderDeadListener { svc = null; ready = false; Engine.notifyUi() }
            Shizuku.addRequestPermissionResultListener { _, _ -> connect(); Engine.notifyUi() }
        } catch (e: Throwable) { /* Shizuku classes unavailable: stay in touch mode */ }
    }

    fun installed(): Boolean = try { app.packageManager.getPackageInfo(SHIZUKU_PKG, 0); true } catch (e: Exception) { false }
    fun running(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
    fun permitted(): Boolean = try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }

    fun requestPermission() {
        if (!running()) { Engine.toast("Start Shizuku first, then press this again"); return }
        try { Shizuku.requestPermission(100) } catch (e: Throwable) { Engine.toast("Couldn't ask Shizuku: ${e.message}") }
    }

    fun connect() {
        if (svc != null || !running() || !permitted()) return
        try {
            val args = Shizuku.UserServiceArgs(ComponentName(app.packageName, KeyInjectorService::class.java.name))
                .daemon(false).processNameSuffix("keys").debuggable(false).version(1)
            Shizuku.bindUserService(args, conn)
        } catch (e: Throwable) { Engine.toast("Couldn't start the key service: ${e.message}") }
    }

    /** The injector, only if it is connected and can really inject. */
    fun service(): IKeyInjector? {
        val s = svc ?: return null
        return if (ready && s.asBinder().isBinderAlive) s else null
    }

    /** Why keyboard mode can't work right now (or "OK"). */
    fun problem(): String = when {
        !installed() -> "Shizuku isn't installed. Install it from Google Play or GitHub."
        !running() -> "Shizuku isn't running. Open Shizuku and start it."
        !permitted() -> "Allow Auto Piano in Shizuku (press 'Grant Shizuku permission')."
        svc == null -> { connect(); "Connecting to Shizuku… try again in a second." }
        !ready -> "Shizuku can't inject keys on this phone: $svcError"
        else -> "OK"
    }

    fun statusText(): String = problem().let { if (it == "OK") "Shizuku: ready" else "Shizuku: $it" }
}
