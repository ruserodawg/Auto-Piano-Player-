package app.autopiano.core

/** A note with absolute times in milliseconds at 100% tempo (tempo map already applied). */
class Note(val startMs: Double, val endMs: Double, val pitch: Int, val channel: Int)

class PedalEvent(val timeMs: Double, val down: Boolean)

class Song(val notes: List<Note>, val pedal: List<PedalEvent>) {
    val durationMs: Double = maxOf(
        notes.maxOfOrNull { it.endMs } ?: 0.0,
        pedal.maxOfOrNull { it.timeMs } ?: 0.0
    )
}

class MidiException(msg: String) : Exception(msg)

object MidiParser {

    private class Reader(val b: ByteArray, var p: Int, val end: Int) {
        fun u8(): Int {
            if (p >= end) throw MidiException("Unexpected end of data")
            return b[p++].toInt() and 0xFF
        }
        fun u16(): Int = (u8() shl 8) or u8()
        fun i32(): Int = (u16() shl 16) or u16()
        fun vlq(): Int {
            var v = 0
            repeat(4) {
                val c = u8()
                v = (v shl 7) or (c and 0x7F)
                if (c and 0x80 == 0) return v
            }
            throw MidiException("Bad variable-length value")
        }
        fun skip(n: Int) { p = minOf(end, p + maxOf(0, n)) }
    }

    private class RawNote(val startTick: Long, var endTick: Long, val pitch: Int, val ch: Int)

    fun parse(data: ByteArray, includeDrums: Boolean = false): Song {
        if (data.size < 14 || String(data, 0, 4, Charsets.ISO_8859_1) != "MThd")
            throw MidiException("Not a MIDI file")
        val hdr = Reader(data, 4, data.size)
        val hlen = hdr.i32()
        hdr.u16() // format (0/1/2 all handled the same: tracks are merged)
        val nTracks = hdr.u16()
        val div = hdr.u16()
        if (div and 0x8000 != 0) throw MidiException("SMPTE timing is not supported")
        if (div == 0) throw MidiException("Invalid time division")

        val tempos = ArrayList<LongArray>()          // [tick, microsecondsPerQuarter]
        val raws = ArrayList<RawNote>()
        val pedalTicks = ArrayList<LongArray>()      // [tick, 1=down 0=up]

        var pos = 8 + hlen
        var tracksRead = 0
        while (tracksRead < nTracks && pos + 8 <= data.size) {
            val id = String(data, pos, 4, Charsets.ISO_8859_1)
            val len = Reader(data, pos + 4, data.size).i32()
            val start = pos + 8
            val end = if (len < 0) data.size else minOf(data.size.toLong(), start.toLong() + len).toInt()
            if (id == "MTrk") {
                parseTrack(Reader(data, start, end), includeDrums, tempos, raws, pedalTicks)
                tracksRead++
            }
            pos = end
        }
        if (raws.isEmpty()) throw MidiException("No notes found")

        // Tempo map
        tempos.sortBy { it[0] }
        val ticks = ArrayList<Long>(); val us = ArrayList<Long>()
        if (tempos.isEmpty() || tempos[0][0] != 0L) { ticks.add(0); us.add(500_000) }
        for (t in tempos) {
            if (ticks.isNotEmpty() && ticks.last() == t[0]) us[us.size - 1] = t[1]
            else { ticks.add(t[0]); us.add(t[1]) }
        }
        val msAt = DoubleArray(ticks.size)
        for (i in 1 until ticks.size)
            msAt[i] = msAt[i - 1] + (ticks[i] - ticks[i - 1]).toDouble() * us[i - 1] / div / 1000.0

        fun toMs(tick: Long): Double {
            var lo = 0; var hi = ticks.size - 1
            while (lo < hi) {
                val mid = (lo + hi + 1) ushr 1
                if (ticks[mid] <= tick) lo = mid else hi = mid - 1
            }
            return msAt[lo] + (tick - ticks[lo]).toDouble() * us[lo] / div / 1000.0
        }

        val notes = raws.map { Note(toMs(it.startTick), toMs(it.endTick), it.pitch, it.ch) }
            .sortedWith(compareBy({ it.startMs }, { it.pitch }))

        pedalTicks.sortBy { it[0] }
        val pedal = ArrayList<PedalEvent>()
        var state = false
        for (p in pedalTicks) {
            val down = p[1] == 1L
            if (down != state) { pedal.add(PedalEvent(toMs(p[0]), down)); state = down }
        }
        if (state && pedal.isNotEmpty()) pedal.add(PedalEvent(notes.maxOf { it.endMs }, false))
        return Song(notes, pedal)
    }

    private fun parseTrack(
        r: Reader, includeDrums: Boolean,
        tempos: MutableList<LongArray>, raws: MutableList<RawNote>, pedal: MutableList<LongArray>
    ) {
        // open notes per (channel, pitch), FIFO so overlapping same-pitch notes pair in order
        val open = HashMap<Int, ArrayDeque<RawNote>>()
        var tick = 0L
        var status = 0
        try {
            loop@ while (r.p < r.end) {
                tick += r.vlq()
                var s = r.u8()
                if (s < 0x80) {
                    if (status == 0) throw MidiException("Bad running status")
                    r.p--; s = status
                } else if (s < 0xF0) status = s else status = 0

                when {
                    s == 0xFF -> {
                        val type = r.u8(); val len = r.vlq()
                        if (type == 0x51 && len == 3) {
                            val v = (r.u8().toLong() shl 16) or (r.u8().toLong() shl 8) or r.u8().toLong()
                            if (v > 0) tempos.add(longArrayOf(tick, v))
                        } else r.skip(len)
                        if (type == 0x2F) break@loop
                    }
                    s == 0xF0 || s == 0xF7 -> r.skip(r.vlq())
                    else -> {
                        val hi = s and 0xF0; val ch = s and 0x0F
                        val d1 = r.u8()
                        val d2 = if (hi == 0xC0 || hi == 0xD0) 0 else r.u8()
                        val drum = ch == 9 && !includeDrums
                        val key = (ch shl 8) or d1
                        when {
                            hi == 0x90 && d2 > 0 -> if (!drum) {
                                val n = RawNote(tick, -1, d1, ch)
                                raws.add(n)
                                open.getOrPut(key) { ArrayDeque() }.addLast(n)
                            }
                            hi == 0x80 || hi == 0x90 -> open[key]?.removeFirstOrNull()?.endTick = tick
                            hi == 0xB0 && d1 == 64 && ch != 9 -> pedal.add(longArrayOf(tick, if (d2 >= 64) 1 else 0))
                        }
                    }
                }
            }
        } catch (_: MidiException) {
            // truncated/corrupt track: keep what was parsed
        }
        for (q in open.values) for (n in q) n.endTick = tick   // close hanging notes
    }
}
