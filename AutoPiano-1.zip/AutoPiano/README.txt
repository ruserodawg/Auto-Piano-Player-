Open this folder in Android Studio -> Build -> Build APK(s).
Phone: install APK, open app, 1) enable accessibility service, 2) import MIDIs, 3) show panel.
