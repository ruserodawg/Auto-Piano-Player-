# Auto Piano (Android)

Private MIDI auto-piano for Roblox Piano. Touch mode via an accessibility service, floating control panel,
MIDI library, live tempo, humanization, tempo jitter, sustain pedal.

Build: push to GitHub; the Actions run "Build APK" produces the `AutoPiano-debug-apk` artifact.
Local: `gradle assembleDebug` (JDK 17, Android SDK 34).

Setup on the phone: enable the accessibility service, allow overlay, import MIDI, pick 61/88 keys,
open the Roblox piano, run "Calibrate touch positions", then play.
