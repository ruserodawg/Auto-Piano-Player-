# Auto Piano (Android)

Private MIDI auto-piano for Roblox Piano. Touch mode via an accessibility service, floating control panel,
MIDI library, live tempo, humanization, tempo jitter, sustain pedal.

Build: push to GitHub; the Actions run "Build APK" produces the `AutoPiano-debug-apk` artifact.
Local: `gradle assembleDebug` (JDK 17, Android SDK 34).

Setup on the phone: enable the accessibility service, allow overlay, import MIDI, pick 61/88 keys,
open the Roblox piano, press "Align piano overlay" and drag the ghost piano over the real keys, then play.

## Keyboard mode (optional, Shizuku)
Settings > Input mode > Keyboard keys. Install Shizuku, start it (Wireless debugging on Android 11+), press
"Grant Shizuku permission", then "Test keys". Standard 61-key Virtual Piano layout; pedal = Space or a touch point.
