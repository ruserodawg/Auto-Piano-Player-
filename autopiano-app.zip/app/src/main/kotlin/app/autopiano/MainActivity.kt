package app.autopiano

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.text.Editable
import android.text.TextWatcher
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var folderText: TextView
    private var filter = ""
    private val ui: () -> Unit = { refreshList(); refreshStatus() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun head(t: String) = TextView(this).apply {
        text = t; textSize = 16f; setPadding(0, dp(16), 0, dp(4))
    }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { f() }
    }
    private fun check(t: String, key: String, def: Boolean) = CheckBox(this).apply {
        text = t; isChecked = Engine.getBool(key, def)
        setOnCheckedChangeListener { _, v -> Engine.setBool(key, v); Engine.applySettings() }
    }
    private fun slider(t: String, key: String, def: Int, maxV: Int = 100, unit: String = "%"): View {
        val label = TextView(this)
        val bar = SeekBar(this).apply { max = maxV; progress = Engine.getInt(key, def) }
        label.text = "$t: ${bar.progress}$unit"
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { label.text = "$t: $p$unit" }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                Engine.setInt(key, bar.progress); Engine.applySettings()
            }
        })
        return LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(label); addView(bar) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.init(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(24), dp(14), dp(24))
        }
        root.addView(TextView(this).apply { text = "Auto Piano"; textSize = 22f })

        status = TextView(this)
        root.addView(head("Setup"))
        root.addView(status)
        root.addView(btn("1. Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(btn("2. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })

        root.addView(head("Player"))
        root.addView(ControlPanel(this))

        root.addView(head("MIDI library"))
        folderText = TextView(this).apply { textSize = 12f }
        root.addView(folderText)
        root.addView(btn("Choose MIDI folder…") {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 11)
        })
        root.addView(LinearLayout(this).apply {
            addView(btn("Rescan") { Engine.refreshLibrary() })
            addView(btn("Use app folder") { Engine.setTree(null) })
        })
        root.addView(EditText(this).apply {
            hint = "Search songs…"; setSingleLine()
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(e: Editable?) { filter = e?.toString() ?: ""; refreshList() }
            })
        })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(listBox)
        root.addView(TextView(this).apply { text = "Tap = select."; textSize = 12f })

        root.addView(head("Piano"))
        val rg = RadioGroup(this).apply { orientation = LinearLayout.HORIZONTAL }
        val r61 = RadioButton(this).apply { text = "61 keys"; id = 61 }
        val r88 = RadioButton(this).apply { text = "88 keys"; id = 88 }
        rg.addView(r61); rg.addView(r88)
        rg.check(if (Engine.is88()) 88 else 61)
        rg.setOnCheckedChangeListener { _, id -> Engine.setIs88(id == 88); refreshStatus() }
        root.addView(rg)
        root.addView(btn("Align piano overlay") {
            if (!Settings.canDrawOverlays(this)) { Engine.toast("Allow display over other apps first"); return@btn }
            PlayerService.ensure(this)
            PianoOverlay(applicationContext).start()
        })

        root.addView(btn("Show / hide piano overlay") { KeyDots.toggle(this) })

        root.addView(head("Humanization"))
        root.addView(check("Humanize timing", "human", false))
        root.addView(slider("Humanize intensity", "hInt", 30))
        root.addView(check("Tempo jitter (slow, bounded wander)", "jitter", false))
        root.addView(slider("Jitter intensity", "jInt", 30))
        root.addView(head("Chords"))
        root.addView(slider("Chord strum, low to high (0 = off)", "arp", 10, 30, " ms/note"))
        root.addView(head("Sustain pedal"))
        root.addView(check("Follow MIDI pedal events when the file has them", "follow", true))

        root.addView(head("Floating panel"))
        root.addView(btn("Show floating panel") {
            if (!Settings.canDrawOverlays(this)) Engine.toast("Allow display over other apps first")
            else PlayerService.show(this)
        })
        root.addView(btn("Hide panel and stop service") { PlayerService.quit(this) })

        root.addView(TextView(this).apply {
            textSize = 12f; setPadding(0, dp(16), 0, 0)
            text = "Touch mode presses keys through an accessibility service: it only works while the service " +
                "is on and calibrated, and a press/release can be up to ~30 ms late. At most 9 notes are held at once: " +
                "bigger chords are strummed and the oldest notes are released early. " +
                "Align the piano in the orientation you play in (each orientation is saved separately). Use Test in the align screen to see which keys really press."
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); Engine.listeners.add(ui); ui() }
    override fun onPause() { Engine.listeners.remove(ui); super.onPause() }

    private fun refreshStatus() {
        val a11y = if (TouchAccessibilityService.instance != null) "ON" else "OFF"
        val ov = if (Settings.canDrawOverlays(this)) "ON" else "OFF"
        val cal = if (Engine.calibration() != null) "set" else "NOT set"
        folderText.text = "Folder: ${Engine.folderLabel()}"
        status.text = "Accessibility service: $a11y\nOverlay permission: $ov\n" +
            "Piano overlay (${if (Engine.is88()) 88 else 61}-key, ${Engine.orientationName()}): $cal\n${Engine.diag()}"
    }

    private fun refreshList() {
        listBox.removeAllViews()
        val all = Engine.library
        val items = all.filter { filter.isBlank() || it.name.contains(filter, ignoreCase = true) }
        if (all.isEmpty()) listBox.addView(TextView(this).apply { text = "No MIDI files found. Choose your MIDI folder." })
        val selected = Engine.currentName()
        for (item in items.take(300)) {
            listBox.addView(TextView(this).apply {
                text = (if (item.name == selected) "▶ " else "    ") + item.name
                textSize = 15f; setPadding(dp(4), dp(10), dp(4), dp(10))
                setOnClickListener { Engine.select(item) }
                if (item.file != null) setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setMessage("Delete ${item.name}?")
                        .setPositiveButton("Delete") { _, _ -> Engine.delete(item) }
                        .setNegativeButton("Cancel", null).show()
                    true
                }
            })
        }
        if (items.size > 300) listBox.addView(TextView(this).apply { text = "Showing 300 of ${items.size}. Use search." })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 11 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
        Engine.setTree(uri)
    }
}
