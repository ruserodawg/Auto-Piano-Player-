rootProject.name = "autopiano-core"
