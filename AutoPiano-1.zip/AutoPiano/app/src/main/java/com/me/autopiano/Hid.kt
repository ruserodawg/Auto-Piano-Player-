package com.me.autopiano

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import java.util.concurrent.Executors

/** Phone acts as a Bluetooth keyboard for ANOTHER device (PC / tablet / 2nd phone). */
@SuppressLint("MissingPermission")
class Hid(private val ctx: Context) {
    private var dev: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private val pressed = LinkedHashMap<Int, Boolean>()
    val connected get() = host != null

    private val desc = intArrayOf(
        0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01,
        0x75, 0x01, 0x95, 0x08, 0x81, 0x02, 0x95, 0x01, 0x75, 0x08, 0x81, 0x01, 0x95, 0x06, 0x75, 0x08,
        0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00, 0xC0
    ).map { it.toByte() }.toByteArray()

    fun start() {
        if (dev != null) return
        val ad = BluetoothAdapter.getDefaultAdapter() ?: return
        ad.getProfileProxy(ctx, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                val d = proxy as BluetoothHidDevice; dev = d
                val sdp = BluetoothHidDeviceAppSdpSettings("AutoPiano", "Keyboard", "AutoPiano",
                    BluetoothHidDevice.SUBCLASS1_KEYBOARD, desc)
                d.registerApp(sdp, null, null, Executors.newSingleThreadExecutor(), object : BluetoothHidDevice.Callback() {
                    override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
                        host = if (state == BluetoothProfile.STATE_CONNECTED) device else null
                    }
                })
            }
            override fun onServiceDisconnected(profile: Int) { dev = null; host = null }
        }, BluetoothProfile.HID_DEVICE)
    }

    fun key(code: Int, shift: Boolean, down: Boolean) {
        if (down) pressed[code] = shift else pressed.remove(code)
        val r = ByteArray(8)
        r[0] = (if (pressed.values.any { it }) 2 else 0).toByte()
        pressed.keys.take(6).forEachIndexed { i, c -> r[2 + i] = c.toByte() }
        val h = host ?: return
        dev?.sendReport(h, 0, r)
    }

    fun releaseAll() { pressed.clear(); val h = host ?: return; dev?.sendReport(h, 0, ByteArray(8)) }
}
